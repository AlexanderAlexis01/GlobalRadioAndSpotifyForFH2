/*
 * FH2 Spotify Radio (minimal)
 * A mod for FH2_ModLoader (Forza Horizon 2 on Azimuth).
 *
 * Turns the game's cut "Xbox Music" station into a radio fed by one of four sources: librespot
 * (Spotify Premium), a music folder, internet radio, or Spotify plus internet radio.
 *
 * The game addresses and the routing technique come from Bullet4fun's spotify-radio mod
 * (FH2_ModsCollection, GPL-3.0). This is a smaller rewrite of the same idea, released under
 * GPL-3.0-or-later. It only works with forza_durango_release_final.exe, timestamp 0x565501ed;
 * every hook compares the original bytes first and is skipped if they differ.
 *
 * Left out compared to the original: next/previous for librespot, romanization of non-Latin titles,
 * the 600 s event restart fallback and FMOD update stall tracking.
 */
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <winhttp.h>
#include <stdlib.h>
#include <stdint.h>
#include "fh2_mod.h"
#include "folder_core.h"
#include "net_util.h"

/* ---- game addresses (RVAs into forza_durango_release_final.exe) ---- */
#define RVA_RADIO_VTABLE       0x2e76818 /* RadioSystem vtable; slot +0xc0 = "is Xbox Music available" */
#define RVA_XBOX_AVAILABLE     0x1012090
#define RVA_XBOX_STREAM_READ   0x1014960 /* FMOD PCM read callback of the endless Xbox Music stream */
#define RVA_STATION_LOCKED     0xa65df0
#define RVA_XBOX_COMMAND       0x1018420 /* RadioSystem Xbox Music command: 0 play, 1 stop */
#define RVA_HUD_RADIO_EVENT    0x7835b0
#define RVA_XBOX_OPTION        0xc72eb0
#define RVA_SNAPSHOT_COPY      0x1024570
#define RVA_SET_POSITION       0x19acec0 /* FMOD Channel::setPosition */
#define RVA_PLAY_SOUND         0x199b0f0 /* FMOD System::playSound */
#define RVA_XBOX_STREAM_VTABLE 0x2e76190
#define RVA_AUDIO_ENGINE_PTR   0x365d3d8
#define RVA_STREAM_FACTORY     0xfeeec0
#define RVA_EVENT_START        0x1a9b390
#define RVA_EVENT_STOP         0x1a9b550
#define RVA_EVENT_GET_TIMELINE 0x1a98b10
#define RVA_EVENT_SET_TIMELINE 0x1a9b040
#define RVA_PARAM_SET_VALUE    0x1a9b1e0
#define RVA_CH_GET_GROUP       0x19abbd0
#define RVA_GRP_GET_PARENT     0x19a7170
#define RVA_CTL_SET_VOLUME     0x19a6470
#define RVA_CTL_GET_DSP        0x19a2860
#define RVA_CTL_GET_NUM_DSPS   0x19a3230
#define RVA_DSP_GET_INFO       0x19a84c0
#define RVA_GRP_GET_NUM_GROUPS 0x19a7050
#define RVA_GRP_GET_GROUP      0x19a6c90
#define RVA_GRP_ADD_GROUP      0x19a6890
#define RVA_DSP_SET_BYPASS     0x19a9cf0

/* ---- small helpers (hook paths avoid the C runtime) ---- */
static unsigned char *g_img;
static HANDLE g_log = INVALID_HANDLE_VALUE;

static void logs(const char *s) {
    DWORD w;
    if (g_log != INVALID_HANDLE_VALUE)
        WriteFile(g_log, s, (DWORD)lstrlenA(s), &w, NULL);
}
static void logn(const char *s, long long v) {
    char b[32];
    int n = 0;
    unsigned long long u = v < 0 ? (unsigned long long)-v : (unsigned long long)v;
    char t[24];
    int k = 0;
    do {
        t[k++] = (char)('0' + u % 10);
        u /= 10;
    } while (u);
    if (v < 0)
        b[n++] = '-';
    while (k)
        b[n++] = t[--k];
    b[n++] = '\r';
    b[n++] = '\n';
    b[n] = 0;
    logs(s);
    logs(" ");
    logs(b);
}
static int same(const void *a, const void *b, size_t n) {
    const unsigned char *x = a, *y = b;
    while (n--)
        if (*x++ != *y++)
            return 0;
    return 1;
}
static void copy(void *d, const void *s, size_t n) {
    unsigned char *x = d;
    const unsigned char *y = s;
    while (n--)
        *x++ = *y++;
}
/* MSVC std::string: chars inline when capacity < 16, else pointer; size at +0x10, capacity at +0x18 */
static int str_is(const void *s, const char *text) {
    size_t n = (size_t)lstrlenA(text);
    const unsigned char *p = s;
    uint64_t size = *(const uint64_t *)(p + 0x10), cap = *(const uint64_t *)(p + 0x18);
    if (size != n)
        return 0;
    return same(cap > 15 ? *(const char *const *)p : (const char *)p, text, n);
}

/* 14-byte absolute jmp at target; the displaced prologue (len >= 14, no RIP-relative bytes) runs from
   the returned trampoline. Never writable+executable at the same time. NULL on failure. */
static void *jmp_hook(unsigned char *target, size_t len, void *fn) {
    static const unsigned char jmp[6] = {0xff, 0x25, 0, 0, 0, 0};
    unsigned char *tr = VirtualAlloc(NULL, 64, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    DWORD old;
    if (!tr)
        return NULL;
    copy(tr, target, len);
    copy(tr + len, jmp, 6);
    uintptr_t back = (uintptr_t)(target + len);
    copy(tr + len + 6, &back, 8);
    if (!VirtualProtect(tr, 64, PAGE_EXECUTE_READ, &old) ||
        !VirtualProtect(target, len, PAGE_EXECUTE_READWRITE, &old)) {
        VirtualFree(tr, 0, MEM_RELEASE);
        return NULL;
    }
    copy(target, jmp, 6);
    uintptr_t to = (uintptr_t)fn;
    copy(target + 6, &to, 8);
    for (size_t i = 14; i < len; ++i)
        target[i] = 0x90;
    VirtualProtect(target, len, old, &old);
    FlushInstructionCache(GetCurrentProcess(), target, len);
    FlushInstructionCache(GetCurrentProcess(), tr, 64);
    return tr;
}
/* checks the original bytes first; skips (and logs) when the exe is not the expected build */
static void *checked_hook(const char *name, uint32_t rva, const unsigned char *expect, size_t len, void *fn) {
    void *tr = NULL;
    if (same(g_img + rva, expect, len))
        tr = jmp_hook(g_img + rva, len, fn);
    logs(tr ? "hooked: " : "SKIPPED (unexpected code): ");
    logs(name);
    logs("\r\n");
    return tr;
}

/* ---- audio ring: librespot -> pump thread -> ring -> game's FMOD stream read ---- */
#define RING_FRAMES (128 * 1024)
#define TARGET      (44100 / 2)              /* keep ~0.5s banked */
#define MAX_BEHIND  (TARGET + 44100 * 3 / 2) /* further behind than this: jump to live */
static Frame g_ring[RING_FRAMES];
static volatile uint64_t g_wr, g_rd, g_last_pull;
static void *volatile g_sound, *volatile g_channel, *volatile g_instance;
static volatile int g_selected;
/* source=both: 1 while Spotify is the tuned station, 0 on an internet station */
static volatile int g_spotify_active = 1;
static volatile int g_flush; /* radio: tuning to another station drops the old audio banked in the ring */

static int stream_read_hook(void *sound, void *data, unsigned len) {
    g_sound = sound; /* FMOD reads once on creation, before Studio plays it: lets playSound find this stream */
    __atomic_store_n(&g_last_pull, GetTickCount64(), __ATOMIC_RELAXED);
    Frame *out = data;
    unsigned n = len / sizeof(Frame);
    static int buffering = 1;
    uint64_t w = __atomic_load_n(&g_wr, __ATOMIC_ACQUIRE), r = g_rd;
    if (__atomic_exchange_n(&g_flush, 0, __ATOMIC_ACQ_REL)) {
        r = w;
        buffering = 1;
    }
    if (w - r > MAX_BEHIND) { /* the game was not listening: catch up */
        r = w - TARGET;
        buffering = 0;
    }
    if (buffering && w - r >= TARGET)
        buffering = 0;
    for (unsigned i = 0; i < n; ++i) {
        if (!buffering && r < w)
            out[i] = g_ring[r++ % RING_FRAMES];
        else { /* underrun: silence until the ring has refilled */
            out[i].l = out[i].r = 0;
            buffering = 1;
        }
    }
    __atomic_store_n(&g_rd, r, __ATOMIC_RELEASE);
    return 0;
}

static DWORD WINAPI pump(LPVOID param);

/* ---- FMOD / Studio function pointers ---- */
typedef int (*Fn_get_group)(void *, void **);
typedef int (*Fn_set_vol)(void *, float);
typedef int (*Fn_get_dsp)(void *, int, void **);
typedef int (*Fn_num_dsps)(void *, int *);
typedef int (*Fn_dsp_info)(void *, char *, unsigned *, int *, int *, int *);
typedef int (*Fn_num_groups)(void *, int *);
typedef int (*Fn_child_group)(void *, int, void **);
typedef int (*Fn_add_group)(void *, void *, unsigned char, void *);
typedef int (*Fn_bypass)(void *, unsigned char);

static int dsp_named(void *ctl, const char *want, void **found) {
    int count = 0;
    Fn_num_dsps num = (Fn_num_dsps)(g_img + RVA_CTL_GET_NUM_DSPS);
    Fn_get_dsp get = (Fn_get_dsp)(g_img + RVA_CTL_GET_DSP);
    Fn_dsp_info info = (Fn_dsp_info)(g_img + RVA_DSP_GET_INFO);
    if (num(ctl, &count) != 0)
        return 0;
    for (int i = 0; i < count && i < 16; ++i) {
        void *dsp = NULL;
        char name[33];
        unsigned ver = 0;
        int c = 0, w = 0, h = 0;
        name[0] = name[32] = 0;
        if (get(ctl, i, &dsp) == 0 && dsp && info(dsp, name, &ver, &c, &w, &h) == 0 && lstrcmpA(name, want) == 0) {
            if (found)
                *found = dsp;
            return 1;
        }
    }
    return 0;
}

/* The Xbox Music event is wired past the radio bus and its Send fader is 0. Re-parent its top group under
   the radio bus (the group with a "Stereo Transceiver" DSP), bypass its Send, raise its fader: it then
   takes the same path as any station track (mixer snapshots, festival speakers, car meets). */
static void route_through_radio_bus(void *channel) {
    Fn_num_groups num_groups = (Fn_num_groups)(g_img + RVA_GRP_GET_NUM_GROUPS);
    Fn_child_group child = (Fn_child_group)(g_img + RVA_GRP_GET_GROUP);
    Fn_add_group add = (Fn_add_group)(g_img + RVA_GRP_ADD_GROUP);
    Fn_bypass bypass = (Fn_bypass)(g_img + RVA_DSP_SET_BYPASS);
    void *group = NULL;
    if (((Fn_get_group)(g_img + RVA_CH_GET_GROUP))(channel, &group) != 0)
        return;
    for (int level = 0; group && level < 8; ++level) {
        void *parent = NULL, *send = NULL, *bus = NULL;
        if (((Fn_get_group)(g_img + RVA_GRP_GET_PARENT))(group, &parent) != 0 || !parent)
            return;
        if (dsp_named(parent, "Stereo Transceiver", NULL))
            bus = parent;
        int siblings = 0;
        for (int i = 0; !bus && num_groups(parent, &siblings) == 0 && i < siblings && i < 64; ++i) {
            void *s = NULL;
            if (child(parent, i, &s) == 0 && s && s != group && dsp_named(s, "Stereo Transceiver", NULL))
                bus = s;
        }
        if (bus) {
            int moved = bus == parent ? 0 : add(bus, group, 1, NULL);
            int byp = dsp_named(group, "FMOD Send", &send) ? bypass(send, 1) : -1;
            ((Fn_set_vol)(g_img + RVA_CTL_SET_VOLUME))(group, 1.0f);
            logn("routed onto radio bus: move result", moved);
            logn("                       send bypass result", byp);
            return;
        }
        group = parent;
    }
}

typedef int (*Fn_play)(void *, void *, void *, int, void **);
static Fn_play g_orig_play;
static int play_sound_hook(void *system, void *sound, void *cgroup, int paused, void **channel) {
    if (!sound || sound != g_sound)
        return g_orig_play(system, sound, cgroup, paused, channel);
    void *local = NULL, **out = channel ? channel : &local;
    int res = g_orig_play(system, sound, cgroup, paused, out);
    if (res == 0 && *out) {
        g_channel = *out;
        route_through_radio_bus(*out);
    }
    return res;
}

typedef int (*Fn_setpos)(void *, unsigned, unsigned);
static Fn_setpos g_orig_setpos;
/* Studio seeks the programmer sound when the event timeline moves; a live stream has no position */
static int set_position_hook(void *ch, unsigned pos, unsigned unit) {
    if (ch && ch == g_channel)
        return 0;
    return g_orig_setpos(ch, pos, unit);
}

/* The Studio event's programmer instrument lasts 600s. Once a second the pump thread moves the timeline
   back 240s when past 300s, so it never ends (the stream just keeps reading the ring). */
static void keep_timeline(void) {
    static ULONGLONG checked;
    ULONGLONG now = GetTickCount64();
    void *inst = g_instance;
    int pos = 0;
    if (!g_selected || !inst || now - checked < 1000)
        return;
    checked = now;
    if (((int (*)(void *, int *))(g_img + RVA_EVENT_GET_TIMELINE))(inst, &pos) != 0 || pos < 300000)
        return;
    ((int (*)(void *, int))(g_img + RVA_EVENT_SET_TIMELINE))(inst, pos - 240000);
}

/* ---- station gate, lock, command ---- */
/* The station gate: always report "Xbox Music available". */
static int gate_hook(void *radio_system) {
    (void)radio_system;
    return 1;
}

typedef int (*Fn_locked)(void *, void *);
static Fn_locked g_orig_locked;
static int locked_hook(void *profile, void *name) {
    int xbox = str_is(name, "Xbox Music"); /* before the original: it frees the string */
    int locked = g_orig_locked(profile, name);
    return xbox ? 0 : locked;
}

typedef void (*Fn_command)(unsigned char *, int);
static Fn_command g_orig_command;

/* The stock game builds only a stub for the dead service. Build the real FMOD stream object (and its Studio
   event "event:/Master/Radio/XboxLiveStreaming") the way the audio engine would, and swap it in. */
static void *xbox_event(unsigned char *decoder) {
    void *obj = *(void **)(decoder + 0x18);
    if (!obj || *(unsigned char **)obj != g_img + RVA_XBOX_STREAM_VTABLE) {
        void *engine = *(void **)(g_img + RVA_AUDIO_ENGINE_PTR), *made[2] = {NULL, NULL};
        if (!engine)
            return NULL;
        ((void *(*)(void **, void *, void *, void *))(g_img + RVA_STREAM_FACTORY))(
            made, (unsigned char *)engine + 0x7f0, NULL, NULL);
        if (!made[0] || *(unsigned char **)made[0] != g_img + RVA_XBOX_STREAM_VTABLE) {
            logs("stream object could not be built\r\n");
            return NULL;
        }
        unsigned char ok =
            (*(unsigned char (**)(void *, void *)) * (void **)made[0])(made[0], decoder); /* vtable[0] = Init */
        *(void **)(decoder + 0x18) = made[0];
        *(void **)(decoder + 0x20) = made[1];
        obj = made[0];
        logn("stream object built, init result", ok);
    }
    return *(void **)((unsigned char *)obj + 0x30);
}
static void command_hook(unsigned char *decoder, int command) {
    if (command != 0 && command != 1) {
        g_orig_command(decoder, command);
        return;
    }
    g_selected = command == 0;
    void *ev = xbox_event(decoder);
    g_instance = ev;
    int res = -1;
    if (ev)
        res = command == 0 ? ((int (*)(void *))(g_img + RVA_EVENT_START))(ev)
                           : ((int (*)(void *, int))(g_img + RVA_EVENT_STOP))(ev, 1);
    logn(command == 0 ? "station on, start result" : "station off, stop result", res);
}

/* ---- radio HUD: drop the sign-in error, show the station banner (logo + title) ----
 * Hooks HudStatusRadioManager::OnSystemEvent. Event 0x10 ("now playing") copies the station (+0x48),
 * track (+0x08) and artist (+0x28) strings into the manager, clears the error flag (+0x78) and pushes
 * them to the HUD view model (0x78a070). The banner and its logo only show when that text is not empty,
 * so on Xbox Music the mod fills it in. Bullet4fun's spotify-radio does the same with Spotify's track. */
typedef void (*Fn_hud)(unsigned char *, int, void *, void *);
static Fn_hud g_orig_hud;
enum { SRC_LIBRESPOT, SRC_FOLDER, SRC_RADIO, SRC_BOTH };
static int g_mode;
static void np_text(char *title, size_t tcap, char *artist, size_t acap);
static void hud_hook(unsigned char *mgr, int category, void *code, void *payload) {
    if (category == 0x22)
        return; /* "XboxRadio" system event = the sign-in error */
    g_orig_hud(mgr, category, code, payload);
    /* 0x10 arrives about every frame: push only changed text, or the banner restarts every time */
    if (category != 0x10 || !str_is(mgr + 0x48, "Xbox Music"))
        return;
    char title[96], artist[48];
    np_text(title, sizeof(title), artist, sizeof(artist));
    if (str_is(mgr + 0x08, title) && str_is(mgr + 0x28, artist) && !mgr[0x78])
        return;
    void (*assign)(void *, const char *, size_t) = (void (*)(void *, const char *, size_t))(g_img + 0x22c300);
    assign(mgr + 0x08, title, (size_t)lstrlenA(title));
    assign(mgr + 0x28, artist, (size_t)lstrlenA(artist));
    mgr[0x78] = 0;
    ((void (*)(void *))(g_img + 0x78a070))(mgr);
    logs("radio HUD banner: ");
    logs(title);
    logs(" / ");
    logs(artist);
    logs("\r\n");
}
typedef void *(*Fn_opt)(void *, void *, unsigned char *, void *);
static Fn_opt g_orig_opt;
static void *option_hook(void *out, void *prop, unsigned char *model, void *extra) {
    if (model)
        model[0x431] = 0;
    return g_orig_opt(out, prop, model, extra);
}

/* ---- mixer snapshot: report RADIO_Station 8 (Xbox Music) as 6 (a stock station) so the festival
        speakers / car-meet mix stay on, instead of fading the TreatedMusic bus to 0 ---- */
typedef void (*Fn_snap)(unsigned char *);
static Fn_snap g_orig_snap;
static void snapshot_hook(unsigned char *mgr) {
    int (*set_value)(void *, float) = (int (*)(void *, float))(g_img + RVA_PARAM_SET_VALUE);
    for (unsigned char *e = *(unsigned char **)(mgr + 0x48); e != *(unsigned char **)(mgr + 0x50); e += 0x20) {
        void *inst = *(void **)(e + 8);
        unsigned char *src = *(unsigned char **)(e + 0x10);
        if (!inst) {
            *(unsigned *)(src + 0x80) = 2;
            continue;
        }
        float v = *(float *)(src + 0x14);
        if (v == 8.0f && str_is(src + 0x60, "RADIO_Station"))
            v = 6.0f;
        set_value(inst, v);
    }
}

/* ---- librespot launcher + pump thread ---- */
static wchar_t g_dir[MAX_PATH * 2], g_mods[MAX_PATH * 2];
static HANDLE g_proc;
static volatile int g_running;
static volatile int g_quit;         /* set when the DLL unloads: stops every thread */
static volatile int g_spotify_dead; /* librespot missing, failed to start or exited: the dial skips Spotify */

/* ---- now playing: track title for the HUD banner ----
 * Folder mode shows the file name. For Spotify, librespot runs onevent.cmd on every track change; it
 * writes nowplaying.txt (UTF-16LE, line 1 the title, the next lines the artists). The HUD font draws one
 * glyph per byte, so accents are decomposed and everything outside printable ASCII is dropped. */
static wchar_t g_work[MAX_PATH * 2]; /* librespot's folder; onevent.cmd and nowplaying.txt live here */
static char g_np_folder[96];
static char g_np_track[96], g_np_artist[48];

static size_t fold_ascii(const wchar_t *w, int n, char *out, size_t cap) {
    size_t o = 0;
    for (int i = 0; i < n; ++i) {
        wchar_t f[8];
        int k = FoldStringW(MAP_COMPOSITE, w + i, 1, f, 8);
        if (k <= 0) {
            f[0] = w[i];
            k = 1;
        }
        for (int j = 0; j < k; ++j)
            if (f[j] >= 32 && f[j] < 127 && o + 1 < cap)
                out[o++] = (char)f[j];
    }
    out[o] = 0;
    return o;
}

static void set_folder_title(const wchar_t *path) {
    const wchar_t *name = path + lstrlenW(path);
    while (name > path && name[-1] != L'\\')
        --name;
    int len = lstrlenW(name), dot = len;
    while (dot > 0 && name[dot - 1] != L'.')
        --dot;
    if (dot > 1)
        len = dot - 1; /* drop the extension */
    char tmp[96];
    fold_ascii(name, len, tmp, sizeof(tmp));
    lstrcpynA(g_np_folder, tmp, sizeof(g_np_folder));
}

/* Called from the HUD hook (game thread); looks at the file twice a second at most. */
static void now_playing_poll(void) {
    static ULONGLONG last;
    static FILETIME stamp;
    static char raw[1024];
    static wchar_t text[600];
    ULONGLONG now = GetTickCount64();
    if (!g_work[0] || now - last < 500)
        return;
    last = now;
    wchar_t path[MAX_PATH * 2];
    lstrcpyW(path, g_work);
    lstrcatW(path, L"nowplaying.txt");
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (!GetFileAttributesExW(path, GetFileExInfoStandard, &fa) || CompareFileTime(&fa.ftLastWriteTime, &stamp) == 0)
        return;
    HANDLE h = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL,
                           OPEN_EXISTING, 0, NULL);
    if (h == INVALID_HANDLE_VALUE)
        return;
    DWORD got = 0;
    BOOL ok = ReadFile(h, raw, sizeof(raw), &got, NULL);
    CloseHandle(h);
    if (!ok || got < 2)
        return;
    stamp = fa.ftLastWriteTime;
    int utf16 = 0, n, first = 0;
    for (DWORD i = 0; i < got; ++i)
        if (!raw[i])
            utf16 = 1;
    if (utf16) { /* UTF-8 text never holds a zero byte, UTF-16 text always does */
        n = (int)(got / 2);
        if (n > 599)
            n = 599;
        copy(text, raw, (size_t)n * 2);
    } else {
        n = MultiByteToWideChar(CP_UTF8, 0, raw, (int)got, text, 599);
    }
    if (n > 0 && text[0] == 0xFEFF)
        first = 1;
    char title[96] = {0}, artist[48] = {0};
    size_t al = 0;
    int line = 0, start = first;
    for (int i = first; i <= n; ++i) {
        if (i < n && text[i] != L'\n')
            continue;
        int end = i;
        while (end > start && text[end - 1] == L'\r')
            --end;
        if (end > start) {
            if (line == 0) {
                fold_ascii(text + start, end - start, title, sizeof(title));
            } else {
                char part[48];
                size_t pl = fold_ascii(text + start, end - start, part, sizeof(part));
                if (pl && al + pl + 3 < sizeof(artist)) {
                    if (al) {
                        artist[al++] = ',';
                        artist[al++] = ' ';
                    }
                    copy(artist + al, part, pl);
                    al += pl;
                    artist[al] = 0;
                }
            }
        }
        ++line;
        start = i + 1;
    }
    if (title[0]) {
        lstrcpynA(g_np_artist, artist, sizeof(g_np_artist));
        lstrcpynA(g_np_track, title, sizeof(g_np_track));
    }
}

/* The script librespot runs on player events (--onevent). cmd /u makes the file UTF-16LE. */
static void write_onevent_script(const wchar_t *dir) {
    static const char script[] = "@echo off\r\n"
                                 "if not defined NAME exit /b\r\n"
                                 "if not \"%~1\"==\"write\" (\r\n"
                                 "  cmd /u /c \"\"%~f0\" write\"\r\n"
                                 "  move /y nowplaying.tmp nowplaying.txt >nul\r\n"
                                 "  exit /b\r\n"
                                 ")\r\n"
                                 "setlocal EnableDelayedExpansion\r\n"
                                 "(\r\n"
                                 "  echo(!NAME!\r\n"
                                 "  echo(!ARTISTS!\r\n"
                                 ") > nowplaying.tmp\r\n";
    wchar_t path[MAX_PATH * 2];
    lstrcpyW(path, dir);
    lstrcatW(path, L"onevent.cmd");
    HANDLE h = CreateFileW(path, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, 0, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        DWORD w;
        WriteFile(h, script, sizeof(script) - 1, &w, NULL);
        CloseHandle(h);
    }
    lstrcpyW(path, dir);
    lstrcatW(path, L"nowplaying.txt"); /* a title left over from the last session */
    DeleteFileW(path);
}

static DWORD WINAPI launcher(LPVOID unused) {
    (void)unused;
    wchar_t exe[MAX_PATH * 2], logp[MAX_PATH * 2];
    const wchar_t *work = g_dir; /* librespot's cache (login) lives next to librespot.exe */
    lstrcpyW(exe, g_dir);
    lstrcatW(exe, L"librespot.exe");
    if (GetFileAttributesW(exe) == INVALID_FILE_ATTRIBUTES) { /* not in mods\FH2_SpotifyMin\: try mods\ itself */
        lstrcpyW(exe, g_mods);
        lstrcatW(exe, L"librespot.exe");
        work = g_mods;
    }
    lstrcpyW(logp, g_dir);
    lstrcatW(logp, L"librespot.log");
    if (GetFileAttributesW(exe) == INVALID_FILE_ATTRIBUTES) {
        logs("librespot.exe not found in data\\bin\\mods\\ or data\\bin\\mods\\FH2_SpotifyMin\\\r\n");
        g_spotify_dead = 1;
        return 0;
    }
    lstrcpynW(g_work, work, MAX_PATH * 2);
    write_onevent_script(work);
    logs("librespot.exe found in: ");
    {
        char b[MAX_PATH * 2];
        WideCharToMultiByte(CP_UTF8, 0, work, -1, b, sizeof(b), NULL, NULL);
        logs(b);
        logs("\r\n");
    }

    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE rd = NULL, wr = NULL;
    if (!CreatePipe(&rd, &wr, &sa, 16 * 1024)) {
        g_spotify_dead = 1;
        return 0;
    }
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);
    HANDLE errlog = CreateFileW(logp, GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS, 0, NULL);
    HANDLE nul = CreateFileW(L"NUL", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa,
                             OPEN_EXISTING, 0, NULL);

    /* a job object so librespot dies with the game */
    HANDLE job = CreateJobObjectW(NULL, NULL);
    if (job) {
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION li;
        for (size_t i = 0; i < sizeof(li); ++i)
            ((unsigned char *)&li)[i] = 0;
        li.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        SetInformationJobObject(job, JobObjectExtendedLimitInformation, &li, sizeof(li));
    }

    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    for (size_t i = 0; i < sizeof(si); ++i)
        ((unsigned char *)&si)[i] = 0;
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = wr;
    si.hStdError = errlog != INVALID_HANDLE_VALUE ? errlog : nul;
    si.hStdInput = nul;
    /* --backend pipe: raw S16LE 44.1kHz stereo on stdout. Login: Spotify's zeroconf (pick the device once
       in the Spotify app, credentials are cached in this folder). Plain upstream librespot is enough. */
    wchar_t cmd[] =
        L"\"librespot.exe\" -v -n \"FH2 Radio\" -b 320 --backend pipe --system-cache . --onevent .\\onevent.cmd";
    if (!CreateProcessW(exe, cmd, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, work, &si, &pi)) {
        logn("could not start librespot, error", GetLastError());
        g_spotify_dead = 1;
        CloseHandle(rd);
    } else {
        if (job)
            AssignProcessToJobObject(job, pi.hProcess);
        g_proc = pi.hProcess;
        CloseHandle(pi.hThread);
        g_running = 1;
        logs("librespot started\r\n");
        CloseHandle(wr);
        wr = NULL;
        if (errlog != INVALID_HANDLE_VALUE)
            CloseHandle(errlog);
        if (nul != INVALID_HANDLE_VALUE)
            CloseHandle(nul);
        pump(rd);
        return 0;
    }
    if (wr)
        CloseHandle(wr);
    return 0;
}

/* While the game listens, its reads set the pace: top the ring up to TARGET and stop, so a full pipe makes
   librespot wait (no drift). While it doesn't, drain at 1x wall clock so Spotify keeps playing in real time. */
static DWORD WINAPI pump(LPVOID param) {
    HANDLE pipe = param;
    static unsigned char tmp[4096];
    const uint64_t bps = 44100 * sizeof(Frame);
    uint64_t consumed = 0, base = 0;
    ULONGLONG clock0 = GetTickCount64();
    size_t carry = 0;
    while (g_running) {
        Sleep(5);
        keep_timeline();
        ULONGLONG now = GetTickCount64();
        int listening = (LONGLONG)(now - __atomic_load_n(&g_last_pull, __ATOMIC_RELAXED)) < 1000 && g_spotify_active;
        uint64_t due;
        if (listening) {
            uint64_t fill = g_wr - __atomic_load_n(&g_rd, __ATOMIC_ACQUIRE);
            due = consumed + (fill < TARGET ? (TARGET - fill) * sizeof(Frame) : 0);
            clock0 = now;
            base = consumed;
        } else {
            due = base + (now - clock0) * bps / 1000;
            if (due > consumed + bps / 10)
                consumed = due - bps / 10; /* paused: don't fast-forward the restart */
        }
        while (g_running && consumed < due) {
            DWORD want = (DWORD)(sizeof(tmp) - carry), got = 0;
            if (due - consumed < want)
                want = (DWORD)(due - consumed);
            if (!ReadFile(pipe, tmp + carry, want, &got, NULL)) {
                DWORD code = 0;
                if (GetLastError() == ERROR_BROKEN_PIPE) { /* librespot is gone */
                    if (g_proc)
                        GetExitCodeProcess(g_proc, &code);
                    logn("librespot exited, exit code", code);
                    g_spotify_dead = 1;
                    g_running = 0;
                }
                break;
            }
            if (got == 0) {
                Sleep(20);
                break;
            }
            consumed += got;
            size_t total = carry + got, frames = total / sizeof(Frame);
            carry = total % sizeof(Frame);
            if (g_spotify_active) {
                uint64_t w = g_wr;
                for (size_t i = 0; i < frames; ++i)
                    g_ring[(w + i) % RING_FRAMES] = ((Frame *)tmp)[i];
                __atomic_store_n(&g_wr, w + frames, __ATOMIC_RELEASE);
            }
            for (size_t c = 0; c < carry; ++c)
                tmp[c] = tmp[total - carry + c];
        }
    }
    return 0;
}

/* Appends frames to the ring (single writer). */
static void ring_write(const Frame *src, size_t frames) {
    uint64_t w = g_wr;
    for (size_t i = 0; i < frames; ++i)
        g_ring[(w + i) % RING_FRAMES] = src[i];
    __atomic_store_n(&g_wr, w + frames, __ATOMIC_RELEASE);
}

/* ---- folder mode: your own mp3 / flac / wav files, decoded inside the mod ---- */
#define MAX_TRACKS 4096
static wchar_t g_folder[MAX_PATH * 2];
static wchar_t g_tracks[MAX_TRACKS][MAX_PATH];
static unsigned g_ntracks;

static int has_ext(const wchar_t *p, const wchar_t *ext) {
    size_t n = (size_t)lstrlenW(p), e = (size_t)lstrlenW(ext);
    return n >= e && lstrcmpiW(p + n - e, ext) == 0;
}
static void scan_dir(const wchar_t *dir, int depth) {
    wchar_t pattern[MAX_PATH * 2];
    WIN32_FIND_DATAW fd;
    lstrcpyW(pattern, dir);
    lstrcatW(pattern, L"\\*");
    HANDLE h = FindFirstFileW(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE)
        return;
    do {
        wchar_t full[MAX_PATH * 2];
        if (fd.cFileName[0] == L'.' && (!fd.cFileName[1] || (fd.cFileName[1] == L'.' && !fd.cFileName[2])))
            continue;
        lstrcpyW(full, dir);
        lstrcatW(full, L"\\");
        lstrcatW(full, fd.cFileName);
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (depth < 3)
                scan_dir(full, depth + 1);
        } else if ((has_ext(full, L".mp3") || has_ext(full, L".flac") || has_ext(full, L".wav")) &&
                   g_ntracks < MAX_TRACKS && lstrlenW(full) < MAX_PATH) {
            lstrcpyW(g_tracks[g_ntracks++], full);
        }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}
static void shuffle(unsigned *order, unsigned n) {
    static uint64_t x = 0;
    if (!x)
        x = GetTickCount64() * 2654435761u + 88172645463325252ull;
    for (unsigned i = 0; i < n; ++i)
        order[i] = i;
    for (unsigned i = n; i > 1; --i) {
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        unsigned j = (unsigned)(x % i), tmp = order[i - 1];
        order[i - 1] = order[j];
        order[j] = tmp;
    }
}

/* Decodes only while the game is listening and the ring has room, so the station pauses with the radio. */
static DWORD WINAPI folder_thread(LPVOID unused) {
    (void)unused;
    static Frame buf[FT_MAX_OUT];
    static unsigned order[MAX_TRACKS];
    scan_dir(g_folder, 0);
    {
        char b[MAX_PATH * 2];
        WideCharToMultiByte(CP_UTF8, 0, g_folder, -1, b, sizeof(b), NULL, NULL);
        logs("music folder: ");
        logs(b);
        logs("\r\n");
    }
    if (!g_ntracks) {
        logs("no mp3/flac/wav files found there; put music in that folder or set folder= in the ini\r\n");
        return 0;
    }
    logn("music files found", g_ntracks);
    g_running = 1;
    shuffle(order, g_ntracks);
    unsigned next = 0, failures = 0;
    while (g_running) {
        if (next >= g_ntracks) {
            shuffle(order, g_ntracks);
            next = 0;
        }
        const wchar_t *path = g_tracks[order[next++]];
        FolderTrack *t = ft_open(path);
        if (!t) {
            if (++failures >= g_ntracks) {
                failures = 0;
                Sleep(1000);
            }
            continue;
        }
        failures = 0;
        set_folder_title(path);
        {
            const wchar_t *name = path + lstrlenW(path);
            while (name > path && name[-1] != L'\\')
                --name;
            char b[MAX_PATH * 4];
            WideCharToMultiByte(CP_UTF8, 0, name, -1, b, sizeof(b), NULL, NULL);
            logs("playing: ");
            logs(b);
            logs("\r\n");
        }
        while (g_running) {
            keep_timeline();
            ULONGLONG now = GetTickCount64();
            int listening = (LONGLONG)(now - __atomic_load_n(&g_last_pull, __ATOMIC_RELAXED)) < 1000;
            uint64_t fill = g_wr - __atomic_load_n(&g_rd, __ATOMIC_ACQUIRE);
            if (!listening || fill >= TARGET) {
                Sleep(10);
                continue;
            }
            size_t got = ft_read(t, buf);
            if (!got)
                break; /* end of track */
            ring_write(buf, got);
        }
        ft_close(t);
    }
    return 0;
}

/* ---- radio mode: live internet radio (mp3 streams), stations from radio-browser.info + my_stations.txt ----
   Network use in this mode only: HTTPS GETs to radio-browser.info (server list + station list for your
   country) and to the station stream URLs. Keys: previous / next station, next country list, show list. */
#define MAX_STATIONS 256
typedef struct {
    char name[96];
    char url[512];
} Station;
static Station g_st[MAX_STATIONS];
static int g_nst, g_cur;
static char g_countries[16][16];
static int g_ncountries, g_country;
static char g_language[48]; /* ini language=: "" = automatic from the country, "any" = no filter */
static int g_limit = 40, g_cache_hours = 12;
static int g_vk[4] = {VK_F6, VK_F5, VK_F7, VK_F8}; /* next, previous, next country, show list */
static char g_keylabel[4][12] = {"F6", "F5", "F7", "F8"};
static volatile int g_action;  /* 1 next, 2 previous, 3 next country, 4 show the list (set by poll_keys) */
static int g_both;             /* source=both: the dial is  Spotify, station 1, station 2, ...  and wraps */
static volatile int g_loading; /* a station list is being downloaded */
static int g_osd_on = 1, g_osd_secs = 5;
static volatile ULONGLONG g_osd_until;

static int parse_key(const wchar_t *w, int def) {
    if (!w[0])
        return def;
    if ((w[0] == L'F' || w[0] == L'f') && w[1] >= L'1' && w[1] <= L'9') {
        int n = w[1] - L'0';
        if (w[2] >= L'0' && w[2] <= L'9')
            n = n * 10 + (w[2] - L'0');
        if (n >= 1 && n <= 24)
            return VK_F1 + n - 1;
    }
    if (!w[1] && ((w[0] >= L'A' && w[0] <= L'Z') || (w[0] >= L'0' && w[0] <= L'9')))
        return (int)w[0];
    if (!w[1] && w[0] >= L'a' && w[0] <= L'z')
        return (int)(w[0] - 32);
    if (w[0] == L'0' && (w[1] == L'x' || w[1] == L'X')) {
        int v = 0;
        for (const wchar_t *c = w + 2; *c; ++c) {
            int d = (*c >= L'0' && *c <= L'9')   ? *c - L'0'
                    : (*c >= L'a' && *c <= L'f') ? *c - L'a' + 10
                    : (*c >= L'A' && *c <= L'F') ? *c - L'A' + 10
                                                 : -1;
            if (d < 0)
                return def;
            v = v * 16 + d;
        }
        return v ? v : def;
    }
    return def;
}
static void set_key(int i, const wchar_t *ini, const wchar_t *name, const wchar_t *def) {
    wchar_t k[24];
    GetPrivateProfileStringW(L"radio", name, def, k, 24, ini);
    g_vk[i] = parse_key(k, parse_key(def, VK_F6));
    for (int c = 0; c < 11 && k[c] && k[c] < 128; ++c) {
        g_keylabel[i][c] = (char)((k[c] >= L'a' && k[c] <= L'z') ? k[c] - 32 : k[c]);
        g_keylabel[i][c + 1] = 0;
    }
}

static int game_has_focus(void) {
    DWORD pid = 0;
    HWND fg = GetForegroundWindow();
    if (!fg)
        return 0;
    GetWindowThreadProcessId(fg, &pid);
    return pid == GetCurrentProcessId();
}
static void poll_keys(void) {
    static int was[4];
    int focus = game_has_focus();
    for (int i = 0; i < 4; ++i) {
        int down = focus && (GetAsyncKeyState(g_vk[i]) & 0x8000) != 0;
        if (down && !was[i] && !g_action)
            g_action = i + 1;
        was[i] = down;
    }
}
static void osd_show(int secs) {
    if (g_osd_on)
        g_osd_until = GetTickCount64() + (ULONGLONG)secs * 1000;
}

/* -- minimal JSON string extraction (radio-browser returns an array of flat objects) -- */
static int json_str(const char *o, size_t n, const char *key, char *out, size_t cap) {
    char pat[40];
    size_t kl = (size_t)lstrlenA(key);
    if (kl + 5 >= sizeof(pat))
        return -1;
    pat[0] = '"';
    copy(pat + 1, key, kl);
    pat[kl + 1] = '"';
    pat[kl + 2] = ':';
    pat[kl + 3] = '"';
    pat[kl + 4] = 0;
    for (size_t i = 0; i + kl + 4 <= n; ++i) {
        if (!same(o + i, pat, kl + 4))
            continue;
        size_t j = i + kl + 4, w = 0;
        while (j < n && o[j] != '"') {
            unsigned c = (unsigned char)o[j];
            if (c == '\\' && j + 1 < n) {
                ++j;
                c = (unsigned char)o[j];
                if (c == 'n' || c == 't' || c == 'r')
                    c = ' ';
                else if (c == 'u' && j + 4 < n) {
                    unsigned v = 0;
                    for (int k = 1; k <= 4; ++k) {
                        unsigned char h = (unsigned char)o[j + k];
                        v = v * 16 + (h >= '0' && h <= '9'                 ? h - '0'
                                      : (h | 32) >= 'a' && (h | 32) <= 'f' ? (h | 32) - 'a' + 10
                                                                           : 0);
                    }
                    j += 4;
                    if (v < 0x80)
                        c = v;
                    else if (v < 0x800) {
                        if (w + 2 < cap) {
                            out[w++] = (char)(0xC0 | (v >> 6));
                            out[w++] = (char)(0x80 | (v & 63));
                        }
                        ++j;
                        continue;
                    } else if (v >= 0xD800 && v <= 0xDFFF)
                        c = '?';
                    else {
                        if (w + 3 < cap) {
                            out[w++] = (char)(0xE0 | (v >> 12));
                            out[w++] = (char)(0x80 | ((v >> 6) & 63));
                            out[w++] = (char)(0x80 | (v & 63));
                        }
                        ++j;
                        continue;
                    }
                }
            }
            if (w + 1 < cap)
                out[w++] = (char)c;
            ++j;
        }
        out[w] = 0;
        return (int)w;
    }
    return -1;
}

/* calls fn(object text) for every top-level {...} of a JSON array */
typedef void (*ObjFn)(const char *o, size_t on);
static void json_each(const char *j, size_t n, ObjFn fn) {
    size_t start = 0;
    int depth = 0, instr = 0, esc = 0;
    for (size_t i = 0; i < n; ++i) {
        char c = j[i];
        if (instr) {
            if (esc)
                esc = 0;
            else if (c == '\\')
                esc = 1;
            else if (c == '"')
                instr = 0;
            continue;
        }
        if (c == '"')
            instr = 1;
        else if (c == '{') {
            if (depth++ == 0)
                start = i;
        } else if (c == '}' && --depth == 0)
            fn(j + start, i - start + 1);
    }
}

/* adds a station: skips empty / non-http entries and duplicates (same name or same stream URL) */
static void add_station(const char *name, const char *url) {
    int i = 0;
    if (g_nst >= MAX_STATIONS || !name[0] || (url[0] != 'h' && url[0] != 'H'))
        return;
    while (name[i] == ' ')
        ++i;
    if (!name[i])
        return;
    for (int k = 0; k < g_nst; ++k)
        if (lstrcmpiA(g_st[k].name, name + i) == 0 || lstrcmpiA(g_st[k].url, url) == 0)
            return;
    lstrcpynA(g_st[g_nst].name, name + i, sizeof(g_st[0].name));
    for (char *c = g_st[g_nst].name; *c; ++c)
        if (*c == '|')
            *c = '/';
    lstrcpynA(g_st[g_nst].url, url, sizeof(g_st[0].url));
    ++g_nst;
}
static void station_obj(const char *o, size_t on) {
    char name[96], url[512];
    int hls = 0;
    for (size_t k = 0; k + 8 <= on; ++k)
        if (same(o + k, "\"hls\":1", 7) || same(o + k, "\"hls\": 1", 8))
            hls = 1;
    if (!hls && json_str(o, on, "name", name, sizeof(name)) > 0 &&
        json_str(o, on, "url_resolved", url, sizeof(url)) > 0)
        add_station(name, url);
}

/* -- WinHTTP (https streams and the radio-browser API) -- */
typedef struct {
    HINTERNET ses, con, req;
} Http;
static void http_close(Http *h) {
    if (h->req)
        WinHttpCloseHandle(h->req);
    if (h->con)
        WinHttpCloseHandle(h->con);
    if (h->ses)
        WinHttpCloseHandle(h->ses);
    h->req = h->con = h->ses = NULL;
}
static int http_start(Http *h, const char *url, wchar_t *ctype, DWORD ctype_chars, DWORD recv_timeout_ms) {
    wchar_t w[1100], host[256], path[900], extra[400], full[1300];
    URL_COMPONENTS uc;
    DWORD status = 0, sz = sizeof(status);
    h->ses = h->con = h->req = NULL;
    if (!MultiByteToWideChar(CP_UTF8, 0, url, -1, w, 1100))
        return 0;
    for (size_t i = 0; i < sizeof(uc); ++i)
        ((unsigned char *)&uc)[i] = 0;
    uc.dwStructSize = sizeof(uc);
    uc.lpszHostName = host;
    uc.dwHostNameLength = 256;
    uc.lpszUrlPath = path;
    uc.dwUrlPathLength = 900;
    uc.lpszExtraInfo = extra;
    uc.dwExtraInfoLength = 400;
    if (!WinHttpCrackUrl(w, 0, 0, &uc))
        return 0;
    host[uc.dwHostNameLength] = 0;
    path[uc.dwUrlPathLength] = 0;
    extra[uc.dwExtraInfoLength] = 0;
    lstrcpyW(full, path[0] ? path : L"/");
    lstrcatW(full, extra);
    h->ses = WinHttpOpen(L"FH2SpotifyMin/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME,
                         WINHTTP_NO_PROXY_BYPASS, 0);
    if (!h->ses)
        return 0;
    WinHttpSetTimeouts(h->ses, 5000, 5000, 5000, (int)recv_timeout_ms);
    h->con = WinHttpConnect(h->ses, host, uc.nPort, 0);
    if (!h->con)
        goto fail;
    h->req = WinHttpOpenRequest(h->con, L"GET", full, NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0);
    if (!h->req)
        goto fail;
    {
        DWORD pol = WINHTTP_OPTION_REDIRECT_POLICY_ALWAYS;
        WinHttpSetOption(h->req, WINHTTP_OPTION_REDIRECT_POLICY, &pol, sizeof(pol));
    }
    if (!WinHttpSendRequest(h->req, L"Accept: */*\r\n", (DWORD)-1, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) ||
        !WinHttpReceiveResponse(h->req, NULL)) {
        logn("  https request failed, error", GetLastError());
        goto fail;
    }
    if (!WinHttpQueryHeaders(h->req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                             WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX) ||
        status != 200) {
        logn("  http status", status);
        goto fail;
    }
    if (ctype) {
        sz = ctype_chars * sizeof(wchar_t);
        ctype[0] = 0;
        WinHttpQueryHeaders(h->req, WINHTTP_QUERY_CONTENT_TYPE, WINHTTP_HEADER_NAME_BY_INDEX, ctype, &sz,
                            WINHTTP_NO_HEADER_INDEX);
    }
    return 1;
fail:
    http_close(h);
    return 0;
}
/* whole response body (station lists, up to 3 MB); caller frees */
static char *http_get_text(const char *url, size_t *len) {
    Http h;
    size_t cap = 65536, n = 0;
    char *b;
    if (!http_start(&h, url, NULL, 0, 15000))
        return NULL;
    b = malloc(cap + 1);
    while (b) {
        DWORD got = 0;
        if (cap - n < 8192) {
            if (cap >= 3u << 20)
                break;
            cap *= 2;
            char *nb = realloc(b, cap + 1);
            if (!nb)
                break;
            b = nb;
        }
        if (!WinHttpReadData(h.req, b + n, (DWORD)(cap - n < 16384 ? cap - n : 16384), &got) || !got)
            break;
        n += got;
    }
    http_close(&h);
    if (!b)
        return NULL;
    b[n] = 0;
    *len = n;
    return b;
}

/* -- files (UTF-8 text, "Name|URL" per line) -- */
static char *read_file_text(const wchar_t *path, size_t *len) {
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    DWORD got = 0, size;
    char *b;
    if (f == INVALID_HANDLE_VALUE)
        return NULL;
    size = GetFileSize(f, NULL);
    if (size == INVALID_FILE_SIZE || size > (4u << 20) || !(b = malloc(size + 1))) {
        CloseHandle(f);
        return NULL;
    }
    if (!ReadFile(f, b, size, &got, NULL))
        got = 0;
    CloseHandle(f);
    b[got] = 0;
    *len = got;
    return b;
}
static void parse_station_lines(char *t) {
    if ((unsigned char)t[0] == 0xEF && (unsigned char)t[1] == 0xBB && (unsigned char)t[2] == 0xBF)
        t += 3; /* UTF-8 BOM */
    for (char *line = t; line && *line;) {
        char *next = line;
        while (*next && *next != '\n')
            ++next;
        if (*next)
            *next++ = 0;
        size_t l = (size_t)lstrlenA(line);
        while (l && (line[l - 1] == '\r' || line[l - 1] == ' '))
            line[--l] = 0;
        char *bar = line;
        while (*bar && *bar != '|')
            ++bar;
        if (*line != '#' && *bar == '|') {
            *bar = 0;
            add_station(line, bar + 1);
        }
        line = next;
    }
}
static void write_file_text(const wchar_t *path, const char *data, size_t n) {
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
    DWORD w;
    if (f == INVALID_HANDLE_VALUE)
        return;
    WriteFile(f, data, (DWORD)n, &w, NULL);
    CloseHandle(f);
}
static int file_age_hours(const wchar_t *p) {
    WIN32_FILE_ATTRIBUTE_DATA d;
    FILETIME now;
    ULARGE_INTEGER a, b;
    if (!GetFileAttributesExW(p, GetFileExInfoStandard, &d))
        return -1;
    GetSystemTimeAsFileTime(&now);
    a.LowPart = now.dwLowDateTime;
    a.HighPart = now.dwHighDateTime;
    b.LowPart = d.ftLastWriteTime.dwLowDateTime;
    b.HighPart = d.ftLastWriteTime.dwHighDateTime;
    if (a.QuadPart < b.QuadPart)
        return 0;
    return (int)((a.QuadPart - b.QuadPart) / 36000000000ULL);
}

/* -- radio-browser: find the live mirrors (official method: never hard-code a single server) -- */
static char g_srv[16][64];
static int g_nsrv;
static void server_obj(const char *o, size_t on) {
    char name[64];
    if (g_nsrv < 16 && json_str(o, on, "name", name, sizeof(name)) > 0 && nu_has_ci(name, ".radio-browser.info") &&
        !nu_has_ci(name, "/"))
        lstrcpynA(g_srv[g_nsrv++], name, 64);
}
static void discover_servers(void) {
    static const char *fallback[] = {"de2", "fi1", "at1", "de1", "nl1"};
    size_t n = 0;
    char *t;
    if (g_nsrv)
        return;
    if ((t = http_get_text("https://all.api.radio-browser.info/json/servers", &n)) != NULL) {
        json_each(t, n, server_obj);
        free(t);
    }
    logn("radio-browser mirrors found", g_nsrv);
    { /* shuffle so one dead mirror is not always hit first */
        unsigned x = (unsigned)GetTickCount64() | 1u;
        for (int i = g_nsrv; i > 1; --i) {
            char tmp[64];
            int j;
            x ^= x << 13;
            x ^= x >> 17;
            x ^= x << 5;
            j = (int)(x % (unsigned)i);
            lstrcpyA(tmp, g_srv[i - 1]);
            lstrcpyA(g_srv[i - 1], g_srv[j]);
            lstrcpyA(g_srv[j], tmp);
        }
    }
    for (int f = 0; f < 5 && g_nsrv < 16; ++f) {
        char name[64];
        int dup = 0;
        wsprintfA(name, "%s.api.radio-browser.info", fallback[f]);
        for (int k = 0; k < g_nsrv; ++k)
            if (lstrcmpiA(g_srv[k], name) == 0)
                dup = 1;
        if (!dup)
            lstrcpyA(g_srv[g_nsrv++], name);
    }
}

static const char *country_language(const char *cc) {
    static const char *map[][2] = {{"IT", "italian"},    {"GB", "english"},    {"US", "english"},  {"AU", "english"},
                                   {"IE", "english"},    {"NZ", "english"},    {"DE", "german"},   {"AT", "german"},
                                   {"FR", "french"},     {"ES", "spanish"},    {"MX", "spanish"},  {"AR", "spanish"},
                                   {"PT", "portuguese"}, {"BR", "portuguese"}, {"NL", "dutch"},    {"PL", "polish"},
                                   {"RU", "russian"},    {"TR", "turkish"},    {"GR", "greek"},    {"SE", "swedish"},
                                   {"NO", "norwegian"},  {"DK", "danish"},     {"FI", "finnish"},  {"CZ", "czech"},
                                   {"RO", "romanian"},   {"HU", "hungarian"},  {"JP", "japanese"}, {"KR", "korean"}};
    for (size_t i = 0; i < sizeof(map) / sizeof(map[0]); ++i)
        if (lstrcmpiA(cc, map[i][0]) == 0)
            return map[i][1];
    return NULL;
}

static int fetch_stations(const char *code, const char *lang) {
    discover_servers();
    for (int i = 0; i < g_nsrv && i < 6 && !g_nst; ++i) {
        char url[600];
        size_t n = 0;
        char *t;
        wsprintfA(url,
                  "https://%s/json/stations/"
                  "search?codec=mp3&hidebroken=true&order=votes&reverse=true&countrycode=%s&limit=%d",
                  g_srv[i], code, g_limit);
        if (lang && lang[0]) {
            lstrcatA(url, "&language=");
            for (const char *c = lang; *c && lstrlenA(url) < 560; ++c) {
                char one[4] = {*c == ' ' ? '+' : *c, 0, 0, 0};
                lstrcatA(url, one);
            }
        }
        logs("fetching stations: ");
        logs(g_srv[i]);
        logs("\r\n");
        if ((t = http_get_text(url, &n)) != NULL) {
            json_each(t, n, station_obj);
            free(t);
        }
        if (!g_nst)
            logs("  no stations from this mirror, trying the next one\r\n");
        else if (i) { /* remember the good one: move it to the front */
            char tmp[64];
            lstrcpyA(tmp, g_srv[i]);
            lstrcpyA(g_srv[i], g_srv[0]);
            lstrcpyA(g_srv[0], tmp);
        }
    }
    return g_nst;
}

static void load_stations(const char *code) {
    wchar_t path[MAX_PATH * 2], wcode[16];
    size_t n = 0;
    char *t, sig[200];
    const char *lang;
    g_nst = 0;
    g_cur = 0;
    MultiByteToWideChar(CP_UTF8, 0, code, -1, wcode, 16);
    if (lstrcmpiA(code, "custom") == 0) {
        lstrcpyW(path, g_dir);
        lstrcatW(path, L"my_stations.txt");
        if (GetFileAttributesW(path) == INVALID_FILE_ATTRIBUTES) {
            static const char tmpl[] = "# One station per line:  Name|http://stream-url   (mp3 streams only; lines "
                                       "starting with # are ignored)\r\n"
                                       "# Example:  My Station|http://example.com:8000/stream.mp3\r\n";
            write_file_text(path, tmpl, sizeof(tmpl) - 1);
        }
        if ((t = read_file_text(path, &n)) != NULL) {
            parse_station_lines(t);
            free(t);
        }
        return;
    }
    /* Without a language filter a country list is "everything broadcast from there": a mix of languages, and
       the dial wraps from the best-voted station to the least-voted one. So filter by the country's language. */
    lang = g_language[0] ? (lstrcmpiA(g_language, "any") == 0 ? NULL : g_language) : country_language(code);
    lstrcpyW(path, g_dir);
    lstrcatW(path, L"stations_");
    lstrcatW(path, wcode);
    lstrcatW(path, L".txt");
    wsprintfA(sig, "# FH2SpotifyMin list v2 %s lang=%s limit=%d", code, lang ? lang : "", g_limit);
    { /* fresh cache for the same settings: instant, and the dial stays the same between sessions */
        int age = file_age_hours(path);
        if (g_cache_hours > 0 && age >= 0 && age < g_cache_hours && (t = read_file_text(path, &n)) != NULL) {
            int match = (size_t)n >= (size_t)lstrlenA(sig) && same(t, sig, (size_t)lstrlenA(sig));
            if (match)
                parse_station_lines(t);
            free(t);
            if (match && g_nst) {
                logn("station list from cache, age in hours", age);
                return;
            }
            g_nst = 0;
        }
    }
    g_loading = 1;
    osd_show(g_osd_secs + 10);
    fetch_stations(code, lang);
    if (g_nst < 8 && lang) {
        logn("few stations with the language filter, retrying without it; had", g_nst);
        g_nst = 0;
        lang = NULL;
        wsprintfA(sig, "# FH2SpotifyMin list v2 %s lang=%s limit=%d", code, "", g_limit);
        fetch_stations(code, NULL);
    }
    g_loading = 0;
    if (g_nst) { /* cache for offline use */
        static char out[MAX_STATIONS * 640 + 256];
        size_t o = (size_t)wsprintfA(out, "%s\r\n", sig);
        for (int i = 0; i < g_nst; ++i)
            o += (size_t)wsprintfA(out + o, "%s|%s\r\n", g_st[i].name, g_st[i].url);
        write_file_text(path, out, o);
    } else if ((t = read_file_text(path, &n)) != NULL) {
        logs("download failed, using the old cached station list\r\n");
        parse_station_lines(t);
        free(t);
    }
}

/* -- live stream session: a reader thread fills a byte FIFO, the decoder drains it.
      http:// streams use a plain socket (WinHTTP rejects SHOUTcast's "ICY 200 OK"), https:// uses WinHTTP -- */
#define FIFO_CAP  (256 * 1024)
#define PREBUFFER (40 * 1024) /* about 2.5 s at 128 kbit/s before decoding starts */
typedef struct {
    Http http;
    SOCKET sock;
    int use_sock;
    HANDLE thread;
    volatile int stop, ended;
    unsigned char *fifo;
    volatile uint64_t wr, rd;
} NetSession;

static int wsa_ready(void) {
    static int state;
    if (!state) {
        WSADATA d;
        state = WSAStartup(MAKEWORD(2, 2), &d) == 0 ? 1 : -1;
    }
    return state > 0;
}
static SOCKET tcp_connect(const char *host, int port, int timeout_ms) {
    struct addrinfo hints, *res = NULL, *ai;
    char ps[8];
    SOCKET s = INVALID_SOCKET;
    for (size_t i = 0; i < sizeof(hints); ++i)
        ((unsigned char *)&hints)[i] = 0;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    wsprintfA(ps, "%d", port);
    if (getaddrinfo(host, ps, &hints, &res) != 0 || !res) {
        logs("  dns lookup failed: ");
        logs(host);
        logs("\r\n");
        return INVALID_SOCKET;
    }
    for (ai = res; ai && s == INVALID_SOCKET && !g_action && !g_quit; ai = ai->ai_next) {
        SOCKET c = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        u_long nb = 1;
        int ok = 0;
        if (c == INVALID_SOCKET)
            continue;
        ioctlsocket(c, FIONBIO, &nb);
        if (connect(c, ai->ai_addr, (int)ai->ai_addrlen) == 0)
            ok = 1;
        else if (WSAGetLastError() == WSAEWOULDBLOCK) {
            for (int waited = 0; waited < timeout_ms && !ok && !g_action && !g_quit; waited += 100) {
                fd_set w, e;
                struct timeval tv;
                FD_ZERO(&w);
                FD_ZERO(&e);
                FD_SET(c, &w);
                FD_SET(c, &e);
                tv.tv_sec = 0;
                tv.tv_usec = 100000;
                if (select(0, NULL, &w, &e, &tv) > 0) {
                    if (FD_ISSET(c, &w))
                        ok = 1;
                    break;
                }
                poll_keys();
            }
        }
        if (ok) {
            nb = 0;
            ioctlsocket(c, FIONBIO, &nb);
            s = c;
        } else
            closesocket(c);
    }
    freeaddrinfo(res);
    if (s == INVALID_SOCKET && !g_action)
        logs("  could not connect\r\n");
    return s;
}

/* connects, sends the GET, reads the response head (SHOUTcast or HTTP), follows redirects.
   1 = body follows (leftover bytes already in the FIFO), 0 = failed / aborted */
static int open_stream(NetSession *s, char *url /* in: start URL, kept as the current URL */, char *ctype, int ccap) {
    for (int hop = 0; hop < 6 && !g_quit && !g_action; ++hop) {
        char host[160], path[420], req[760], head[8192], loc[512];
        int https, port, rl = 0, n = 0, he = 0, status;
        if (!nu_split_url(url, &https, host, sizeof(host), &port, path, sizeof(path))) {
            logs("  bad stream URL\r\n");
            return 0;
        }
        if (https) { /* WinHTTP: certificate checks, TLS 1.2/1.3, its own redirects */
            wchar_t wct[128];
            if (!http_start(&s->http, url, wct, 128, 10000))
                return 0;
            s->use_sock = 0;
            WideCharToMultiByte(CP_UTF8, 0, wct, -1, ctype, ccap, NULL, NULL);
            for (char *c = ctype; *c; ++c)
                *c = (char)nu_lower((unsigned char)*c);
            return 1;
        }
        if (!wsa_ready()) {
            logs("  winsock not available\r\n");
            return 0;
        }
        s->sock = tcp_connect(host, port, 6000);
        if (s->sock == INVALID_SOCKET)
            return 0;
        {
            DWORD to = 10000;
            setsockopt(s->sock, SOL_SOCKET, SO_SNDTIMEO, (const char *)&to, sizeof(to));
            setsockopt(s->sock, SOL_SOCKET, SO_RCVTIMEO, (const char *)&to, sizeof(to));
        }
        nu_cat(req, sizeof(req), &rl, "GET ");
        nu_cat(req, sizeof(req), &rl, path);
        nu_cat(req, sizeof(req), &rl, " HTTP/1.0\r\nHost: ");
        nu_cat(req, sizeof(req), &rl, host);
        nu_cat(req, sizeof(req), &rl, "\r\nUser-Agent: FH2SpotifyMin/1.0\r\nAccept: */*\r\nConnection: close\r\n\r\n");
        if (send(s->sock, req, rl, 0) != rl) {
            logs("  send failed\r\n");
            closesocket(s->sock);
            s->sock = INVALID_SOCKET;
            return 0;
        }
        for (int waited = 0;
             !(he = nu_head_end(head, n)) && n < (int)sizeof(head) && waited < 10000 && !g_quit && !g_action;
             waited += 100) {
            fd_set r;
            struct timeval tv;
            int got;
            FD_ZERO(&r);
            FD_SET(s->sock, &r);
            tv.tv_sec = 0;
            tv.tv_usec = 100000;
            if (select(0, &r, NULL, NULL, &tv) <= 0) {
                poll_keys();
                continue;
            }
            got = recv(s->sock, head + n, (int)sizeof(head) - n, 0);
            if (got <= 0)
                break;
            n += got;
            waited = 0;
        }
        if (!he) {
            logs("  no valid response head\r\n");
            closesocket(s->sock);
            s->sock = INVALID_SOCKET;
            return 0;
        }
        status = nu_parse_head(head, he, ctype, ccap, loc, sizeof(loc));
        if ((status == 301 || status == 302 || status == 303 || status == 307 || status == 308) && loc[0] &&
            nu_resolve(https, host, port, loc, url, 512)) {
            closesocket(s->sock);
            s->sock = INVALID_SOCKET;
            continue; /* url is now the redirect target (http or https) */
        }
        if (status != 200) {
            logn("  stream answered status", status);
            closesocket(s->sock);
            s->sock = INVALID_SOCKET;
            return 0;
        }
        {
            int left = n - he;
            if (left > 0) {
                copy(s->fifo, head + he, (size_t)left);
                s->wr = (uint64_t)left;
            }
        }
        s->use_sock = 1;
        return 1;
    }
    return 0;
}

static DWORD WINAPI net_reader(LPVOID p) {
    NetSession *s = p;
    unsigned char tmp[4096];
    while (!s->stop) {
        DWORD got = 0;
        uint64_t w = s->wr;
        if (w - __atomic_load_n(&s->rd, __ATOMIC_ACQUIRE) > FIFO_CAP - sizeof(tmp)) {
            Sleep(5);
            continue;
        }
        if (s->use_sock) {
            int r = recv(s->sock, (char *)tmp, (int)sizeof(tmp), 0);
            if (r <= 0)
                break;
            got = (DWORD)r;
        } else if (!WinHttpReadData(s->http.req, tmp, sizeof(tmp), &got) || !got)
            break;
        for (DWORD i = 0; i < got; ++i)
            s->fifo[(w + i) % FIFO_CAP] = tmp[i];
        __atomic_store_n(&s->wr, w + got, __ATOMIC_RELEASE);
    }
    s->ended = 1;
    return 0;
}
static size_t net_read(void *u, void *buf, size_t n) {
    NetSession *s = u;
    for (;;) {
        uint64_t w = __atomic_load_n(&s->wr, __ATOMIC_ACQUIRE), r = s->rd;
        if (w > r) {
            size_t k = (size_t)(w - r) < n ? (size_t)(w - r) : n;
            for (size_t i = 0; i < k; ++i)
                ((unsigned char *)buf)[i] = s->fifo[(r + i) % FIFO_CAP];
            __atomic_store_n(&s->rd, r + k, __ATOMIC_RELEASE);
            return k;
        }
        if (s->ended || s->stop || g_quit || g_action)
            return 0;
        poll_keys(); /* stay responsive while waiting for a stalled stream */
        Sleep(5);
    }
}
static void session_close(NetSession **sp) {
    NetSession *s = *sp;
    if (!s)
        return;
    s->stop = 1;
    if (s->sock != INVALID_SOCKET) { /* closing the socket aborts a blocked recv */
        shutdown(s->sock, SD_BOTH);
        closesocket(s->sock);
        s->sock = INVALID_SOCKET;
    }
    http_close(&s->http);
    if (s->thread) {
        WaitForSingleObject(s->thread, 3000);
        CloseHandle(s->thread);
    }
    free(s->fifo);
    free(s);
    *sp = NULL;
}
static NetSession *session_open(const char *url0) {
    NetSession *s = calloc(1, sizeof(*s));
    char url[512], ctype[128];
    if (!s)
        return NULL;
    s->sock = INVALID_SOCKET;
    s->fifo = malloc(FIFO_CAP);
    lstrcpynA(url, url0, sizeof(url));
    if (!s->fifo || !open_stream(s, url, ctype, sizeof(ctype))) {
        if (!g_action)
            logs("  could not connect to the stream\r\n");
        free(s->fifo);
        free(s);
        return NULL;
    }
    if (!nu_ctype_ok(ctype)) {
        logs("  not an mp3 stream, content type: ");
        logs(ctype);
        logs("\r\n");
        if (s->sock != INVALID_SOCKET)
            closesocket(s->sock);
        http_close(&s->http);
        free(s->fifo);
        free(s);
        return NULL;
    }
    s->thread = CreateThread(NULL, 0, net_reader, s, 0, NULL);
    for (int waited = 0; waited < 10000 && !s->ended && !g_quit && !g_action; waited += 20) {
        if (s->wr - s->rd >= PREBUFFER)
            return s;
        poll_keys();
        Sleep(20);
    }
    if (s->wr - s->rd >= 4096 && !g_action)
        return s;
    session_close(&s);
    return NULL;
}

static void tune_log(const char *prefix) {
    char n[8];
    if (g_both && g_spotify_active) {
        logs(prefix);
        logs("Spotify (device \"FH2 Radio\")\r\n");
        return;
    }
    wsprintfA(n, " %d/%d", g_cur + 1, g_nst);
    logs(prefix);
    logs(g_countries[g_country]);
    logs(n);
    logs(": ");
    logs(g_nst ? g_st[g_cur].name : "(no stations)");
    logs("\r\n");
}

/* ---- on-screen station list (small click-through window over the game; only while it is shown) ---- */
typedef struct {
    DWORD pid;
    HWND best;
    long area;
} WinSearch;
static HWND g_osd;
static BOOL CALLBACK osd_enum(HWND h, LPARAM lp) {
    WinSearch *w = (WinSearch *)lp;
    DWORD pid = 0;
    RECT r;
    GetWindowThreadProcessId(h, &pid);
    if (pid != w->pid || h == g_osd || !IsWindowVisible(h) || GetWindow(h, GW_OWNER))
        return TRUE;
    GetWindowRect(h, &r);
    if ((long)(r.right - r.left) * (r.bottom - r.top) > w->area) {
        w->area = (long)(r.right - r.left) * (r.bottom - r.top);
        w->best = h;
    }
    return TRUE;
}
#define OSD_ROWS 9
static void osd_lines(wchar_t lines[OSD_ROWS + 3][128], int *sel) {
    int n = 0;
    char title[160];
    *sel = -1;
    if (g_loading)
        wsprintfA(title, "FH2 Radio - loading %s ...", g_countries[g_country]);
    else if (g_both && g_spotify_active)
        wsprintfA(title, "FH2 Radio - Spotify (device \"FH2 Radio\")");
    else
        wsprintfA(title, "FH2 Radio - %s - %d stations", g_countries[g_country], g_nst);
    MultiByteToWideChar(CP_UTF8, 0, title, -1, lines[n++], 128);
    if (!g_loading) {
        int cur = (g_both && g_spotify_active) ? -1 : g_cur, first = cur < 0 ? 0 : cur - OSD_ROWS / 2;
        if (first > g_nst - OSD_ROWS)
            first = g_nst - OSD_ROWS;
        if (first < 0)
            first = 0;
        if (!g_nst)
            lstrcpyW(lines[n++], L"(no stations - see FH2_SpotifyMin.log)");
        for (int i = first; i < g_nst && i < first + OSD_ROWS; ++i) {
            char row[130];
            wchar_t wname[100];
            MultiByteToWideChar(CP_UTF8, 0, g_st[i].name, -1, wname, 100);
            wsprintfA(row, "%s %2d. ", i == cur ? ">" : " ", i + 1);
            MultiByteToWideChar(CP_UTF8, 0, row, -1, lines[n], 128);
            lstrcpynW(lines[n] + lstrlenW(lines[n]), wname, 110 - lstrlenW(lines[n]));
            if (i == cur)
                *sel = n;
            ++n;
        }
        {
            char foot[128];
            wsprintfA(foot, "%s prev   %s next   %s country   %s list", g_keylabel[1], g_keylabel[0], g_keylabel[2],
                      g_keylabel[3]);
            MultiByteToWideChar(CP_UTF8, 0, foot, -1, lines[n++], 128);
        }
    }
    lines[n][0] = 0;
}
static LRESULT CALLBACK osd_proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == WM_PAINT) {
        static wchar_t lines[OSD_ROWS + 3][128];
        PAINTSTRUCT ps;
        RECT rc;
        int sel, i;
        HDC dc = BeginPaint(h, &ps);
        HFONT font =
            CreateFontW(-18, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
        HBRUSH bg = CreateSolidBrush(RGB(14, 16, 26));
        HGDIOBJ old = SelectObject(dc, font);
        GetClientRect(h, &rc);
        FillRect(dc, &rc, bg);
        SetBkMode(dc, TRANSPARENT);
        osd_lines(lines, &sel);
        for (i = 0; lines[i][0]; ++i) {
            SetTextColor(dc, i == 0 ? RGB(120, 200, 255) : i == sel ? RGB(255, 225, 90) : RGB(235, 235, 235));
            TextOutW(dc, 12, 8 + i * 24, lines[i], lstrlenW(lines[i]));
        }
        SelectObject(dc, old);
        DeleteObject(font);
        DeleteObject(bg);
        EndPaint(h, &ps);
        return 0;
    }
    if (m == WM_ERASEBKGND)
        return 1;
    if (m == WM_NCHITTEST)
        return HTTRANSPARENT;
    return DefWindowProcW(h, m, w, l);
}
static DWORD WINAPI osd_thread(LPVOID unused) {
    (void)unused;
    static wchar_t lines[OSD_ROWS + 3][128];
    WNDCLASSW wc;
    HINSTANCE hi = GetModuleHandleW(NULL);
    int shown = 0;
    ULONGLONG moved = 0;
    for (size_t i = 0; i < sizeof(wc); ++i)
        ((unsigned char *)&wc)[i] = 0;
    wc.lpfnWndProc = osd_proc;
    wc.hInstance = hi;
    wc.lpszClassName = L"FH2SpotifyMinOSD";
    if (!RegisterClassW(&wc))
        return 0;
    g_osd = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW,
                            L"FH2SpotifyMinOSD", L"", WS_POPUP, 0, 0, 10, 10, NULL, NULL, hi, NULL);
    if (!g_osd) {
        logs("on-screen list: could not create the window\r\n");
        return 0;
    }
    SetLayeredWindowAttributes(g_osd, 0, 225, LWA_ALPHA);
    while (!g_quit) {
        MSG msg;
        ULONGLONG now = GetTickCount64();
        while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        if (now < g_osd_until && game_has_focus()) {
            if (!shown || now - moved > 250) {
                WinSearch ws;
                RECT r;
                int sel, rows = 0, x = 20, y = 90;
                ws.pid = GetCurrentProcessId();
                ws.best = NULL;
                ws.area = 0;
                EnumWindows(osd_enum, (LPARAM)&ws);
                if (ws.best && GetWindowRect(ws.best, &r)) {
                    x = r.left + 24;
                    y = r.top + 90;
                }
                osd_lines(lines, &sel);
                while (lines[rows][0])
                    ++rows;
                SetWindowPos(g_osd, HWND_TOPMOST, x, y, 430, rows * 24 + 16,
                             SWP_NOACTIVATE | (shown ? 0 : SWP_SHOWWINDOW));
                InvalidateRect(g_osd, NULL, FALSE);
                moved = now;
                shown = 1;
            }
        } else if (shown) {
            ShowWindow(g_osd, SW_HIDE);
            shown = 0;
        }
        Sleep(40);
    }
    return 0;
}

static DWORD WINAPI radio_thread(LPVOID unused) {
    (void)unused;
    static Frame buf[FT_MAX_OUT];
    NetSession *ses = NULL;
    FolderTrack *trk = NULL;
    ULONGLONG retry_at = 0;
    int dir = 1, fails = 0, was_listening = 0;
    g_running = 1;
    g_spotify_active = g_both ? 1 : 0;
    load_stations(g_countries[g_country]);
    logn("stations loaded", g_nst);
    tune_log("station ");
    while (!g_quit) {
        poll_keys();
        if (g_both && g_spotify_active &&
            g_spotify_dead) { /* no librespot / it exited: the dial starts on the radio stations */
            g_spotify_active = 0;
            __atomic_store_n(&g_flush, 1, __ATOMIC_RELEASE);
            logs("Spotify is not available, staying on the radio stations\r\n");
            tune_log("tuned ");
        }
        if (g_action) {
            int a = g_action;
            int has_sp = g_both && !g_spotify_dead;
            if (a == 4) { /* just show the list */
                osd_show(8);
                g_action = 0;
                continue;
            }
            if (trk) {
                ft_close(trk);
                trk = NULL;
            }
            session_close(&ses);
            if (a == 3) {
                if (g_ncountries > 1) {
                    g_country = (g_country + 1) % g_ncountries;
                    logs("loading stations for ");
                    logs(g_countries[g_country]);
                    logs("\r\n");
                    osd_show(g_osd_secs + 10);
                    load_stations(g_countries[g_country]);
                    logn("stations loaded", g_nst);
                    g_spotify_active = 0;
                } else
                    logs("only one country in the ini (countries=), nothing to switch\r\n");
            } else if (has_sp) {
                int n = g_nst + 1, slot = g_spotify_active ? 0 : g_cur + 1; /* slot 0 = Spotify */
                slot = (a == 2) ? (slot + n - 1) % n : (slot + 1) % n;
                g_spotify_active = (slot == 0);
                if (slot)
                    g_cur = slot - 1;
            } else if (g_nst) {
                g_cur = (a == 2) ? (g_cur + g_nst - 1) % g_nst : (g_cur + 1) % g_nst;
            }
            dir = a == 2 ? -1 : 1;
            fails = 0;
            tune_log("tuned ");
            osd_show(g_osd_secs);
            __atomic_store_n(&g_flush, 1, __ATOMIC_RELEASE); /* drop what the old station left in the ring */
            retry_at = 0;
            g_action = 0;
        }
        keep_timeline();
        ULONGLONG now = GetTickCount64(), last = __atomic_load_n(&g_last_pull, __ATOMIC_RELAXED);
        int listening = (LONGLONG)(now - last) < 1000 && !g_spotify_active;
        if (listening && !was_listening)
            osd_show(g_osd_secs); /* just tuned the Xbox Music station: show the list */
        was_listening = listening || (g_spotify_active && (LONGLONG)(now - last) < 1000);
        if (g_spotify_active) { /* Spotify is the tuned station: the pump feeds the ring */
            Sleep(20);
            continue;
        }
        if (!listening) {
            if ((trk || ses) && (LONGLONG)(now - last) > 4000) { /* left the station: tuning back in starts live */
                if (trk) {
                    ft_close(trk);
                    trk = NULL;
                }
                session_close(&ses);
            }
            Sleep(20);
            continue;
        }
        if (!trk) {
            int failed = 0;
            if (now < retry_at || !g_nst) {
                Sleep(20);
                continue;
            }
            logs("connecting: ");
            logs(g_st[g_cur].name);
            logs("\r\n");
            ses = session_open(g_st[g_cur].url);
            if (!ses)
                failed = 1;
            else if (!(trk = ft_open_mp3_stream(net_read, ses))) {
                logs("  could not decode this stream (not mp3?)\r\n");
                session_close(&ses);
                failed = 1;
            }
            if (failed && !g_action) {
                if (++fails < g_nst) { /* dead station: move on in the direction of the last key press */
                    logs("  skipping this station\r\n");
                    g_cur = (g_cur + g_nst + dir) % g_nst;
                    tune_log("tuned ");
                    osd_show(g_osd_secs);
                    __atomic_store_n(&g_flush, 1, __ATOMIC_RELEASE);
                } else
                    retry_at = now + 3000; /* every station of the list failed: slow retry (network down?) */
            }
            if (!trk)
                continue;
            fails = 0;
            logn("on air, source sample rate", ft_source_rate(trk));
            continue;
        }
        if (g_wr - __atomic_load_n(&g_rd, __ATOMIC_ACQUIRE) >= TARGET) {
            Sleep(10);
            continue;
        }
        size_t got = ft_read(trk, buf);
        if (!got) {
            if (g_action)
                continue;
            logs("stream ended or lost, reconnecting\r\n");
            ft_close(trk);
            trk = NULL;
            session_close(&ses);
            retry_at = now + 1500;
            continue;
        }
        ring_write(buf, got);
    }
    return 0;
}

/* ---- HUD banner text: radio = station name + "global RADIO"; Spotify and folder = track + artist ----
 * The HUD font draws one glyph per byte, so everything outside printable ASCII is dropped. */
static void ascii_only(char *dst, size_t cap, const char *src, size_t max_chars) {
    size_t n = 0;
    for (; *src && n + 1 < cap && n < max_chars; ++src)
        if ((unsigned char)*src >= 32 && (unsigned char)*src < 127)
            dst[n++] = *src;
    while (n && dst[n - 1] == ' ')
        --n;
    dst[n] = 0;
}
static void np_text(char *title, size_t tcap, char *artist, size_t acap) {
    int radio_on =
        (g_mode == SRC_RADIO || (g_mode == SRC_BOTH && !g_spotify_active)) && g_nst > 0 && g_cur >= 0 && g_cur < g_nst;
    int spotify_on = g_mode == SRC_LIBRESPOT || (g_mode == SRC_BOTH && g_spotify_active);
    title[0] = 0;
    if (radio_on) {
        ascii_only(title, tcap, g_st[g_cur].name, 60);
        ascii_only(artist, acap, "global RADIO", 40);
    } else if (spotify_on) {
        now_playing_poll();
        ascii_only(title, tcap, g_np_track, 60);
        ascii_only(artist, acap, g_np_artist[0] ? g_np_artist : "Spotify", 40);
    } else if (g_mode == SRC_FOLDER) {
        ascii_only(title, tcap, g_np_folder, 60);
        ascii_only(artist, acap, "Music folder", 40);
    } else {
        ascii_only(artist, acap, "Spotify", 40);
    }
    if (!title[0])
        ascii_only(title, tcap, "global RADIO", 60);
}

/* ---- station logo (mounting code taken from Bullet4fun's spotify-radio) ----
 * HUD_RadioIcon_Global.swatchbin in the mod folder is copied to
 *   <game folder>\spotifyradio\ui\textures\Anthem\HUD\HUD_RadioIcon_Xbox_Music.swatchbin
 * and that folder is mounted over game:\media\ on the game's first file lookup, below any user
 * mediaoverride folder. Without the file, or if the code at the lookup differs, the stock icon stays. */
typedef struct {
    const char *data;
    uintptr_t reserved;
    size_t length, capacity;
} GameString; /* MSVC std::string */
typedef unsigned char (*ResolveFileFn)(void *, void **, void *, const void *, unsigned char, unsigned char,
                                       unsigned char, void **, unsigned char);
static ResolveFileFn g_orig_resolve;
static unsigned char (*g_folder_file_exists)(void *, const GameString *);
static void *g_folder_vtable[1 + 0x1f0 / sizeof(void *)];
static volatile LONG g_mount_state;

static GameString game_string(const char *t) {
    GameString g = {t, 0, (size_t)lstrlenA(t), 31};
    return g;
}

static unsigned char folder_file_exists_hook(void *volume, const GameString *path) {
    const char *text = path->capacity < 16 ? (const char *)path : path->data;
    for (size_t i = 0; i < path->length; ++i) { /* archive selectors such as <*>0 are not filenames */
        unsigned char c = (unsigned char)text[i];
        if (c < 32 || c == '<' || c == '>' || c == '*' || c == '?' || c == '"' || c == '|')
            return 0;
    }
    return g_folder_file_exists(volume, path);
}

static void mount_logo_folder(void *filesystem) {
    if (g_mount_state || !*(void **)((unsigned char *)filesystem + 0x68) ||
        InterlockedCompareExchange(&g_mount_state, 1, 0) != 0)
        return;
    int mounted = 0;
    void *storage = ((void *(*)(size_t))(g_img + 0x3229c0))(0x50);
    if (storage) {
        GameString source = game_string("game:\\spotifyradio\\"), destination = game_string("game:\\media\\");
        void *volume = ((void *(*)(void *, const void *, unsigned char))(g_img + 0x11e05a0))(storage, &source, 1);
        *(void ***)volume = g_folder_vtable + 1;
        void **methods = *(void ***)volume;
        ((void (*)(void *))methods[0x10 / 8])(volume);
        void **fsm = *(void ***)filesystem;
        mounted =
            ((unsigned char (*)(void *, const void *, void **, unsigned, unsigned char, unsigned char,
                                const void *))fsm[0x1e8 / 8])(filesystem, &destination, &volume, 0x7ffffffc, 0, 0, 0);
        ((void (*)(void *))methods[0x18 / 8])(volume);
        ((void (*)(void *))fsm[0x1f8 / 8])(filesystem);
    }
    InterlockedExchange(&g_mount_state, 2);
    logs(mounted ? "logo folder mounted; the station shows the custom logo\r\n"
                 : "logo folder mount FAILED; stock logo stays\r\n");
}

static unsigned char resolve_file_hook(void *filesystem, void **volume, void *relative_path, const void *path,
                                       unsigned char f1, unsigned char f2, unsigned char f3, void **mount,
                                       unsigned char f4) {
    mount_logo_folder(filesystem);
    return g_orig_resolve(filesystem, volume, relative_path, path, f1, f2, f3, mount, f4);
}

static void install_logo(const FH2ModHost *host) {
    static const unsigned char resolve_pro[15] = {0x48, 0x8b, 0xc4, 0x4c, 0x89, 0x48, 0x20, 0x48,
                                                  0x89, 0x50, 0x10, 0x48, 0x89, 0x48, 0x08};
    wchar_t src[MAX_PATH * 2], dst[MAX_PATH * 2];
    lstrcpyW(src, g_dir);
    lstrcatW(src, L"HUD_RadioIcon_Global.swatchbin");
    if (GetFileAttributesW(src) == INVALID_FILE_ATTRIBUTES) {
        logs("no HUD_RadioIcon_Global.swatchbin in the mod folder; stock logo stays\r\n");
        return;
    }
    size_t cut = 0; /* game_exe is ...\Mount\forza_durango_release_final.exe; the logo folder goes beside it */
    for (size_t i = 0; host->game_exe[i]; ++i)
        if (host->game_exe[i] == L'\\' || host->game_exe[i] == L'/')
            cut = i + 1;
    if (!cut || cut > MAX_PATH)
        return;
    for (size_t i = 0; i < cut; ++i)
        dst[i] = host->game_exe[i];
    dst[cut] = 0;
    lstrcatW(dst, L"spotifyradio\\ui\\textures\\Anthem\\HUD\\HUD_RadioIcon_Xbox_Music.swatchbin");
    for (size_t i = cut; dst[i]; ++i) { /* create the folders as needed */
        if (dst[i] == L'\\') {
            dst[i] = 0;
            CreateDirectoryW(dst, NULL);
            dst[i] = L'\\';
        }
    }
    if (!CopyFileW(src, dst, FALSE)) {
        logn("could not copy the logo into the game folder, error", (long long)GetLastError());
        return;
    }
    copy(g_folder_vtable, g_img + 0x2eab910, sizeof(g_folder_vtable)); /* keeps the RTTI slot */
    g_folder_file_exists = (unsigned char (*)(void *, const GameString *))g_folder_vtable[1 + 0xe8 / 8];
    g_folder_vtable[1 + 0xe8 / 8] = (void *)folder_file_exists_hook;
    if (same(g_img + 0x11f49b0, resolve_pro, sizeof(resolve_pro)))
        g_orig_resolve = (ResolveFileFn)jmp_hook(g_img + 0x11f49b0, sizeof(resolve_pro), (void *)resolve_file_hook);
    logs(g_orig_resolve ? "logo installed; its folder is mounted on the game's first file lookup\r\n"
                        : "file lookup hook SKIPPED (unexpected code); stock logo stays\r\n");
}

/* ---- entry point (called by the loader inside its DllMain: patch, start a thread, never wait) ---- */
BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID r) {
    (void)h;
    (void)r;
    if (reason == DLL_PROCESS_DETACH) {
        g_quit = 1;
        g_running = 0;
    }
    return TRUE;
}

__declspec(dllexport) int FH2ModLoad(const FH2ModHost *host) {
    if (!host || host->size < sizeof(*host) || host->api_version != FH2_MOD_API_VERSION || !host->game_image)
        return 0;
    g_img = host->game_image;
    CreateDirectoryW(host->data_dir, NULL);
    lstrcpyW(g_dir, host->data_dir);
    lstrcpyW(g_mods, host->mods_dir);
    wchar_t lp[MAX_PATH * 2];
    lstrcpyW(lp, g_dir);
    lstrcatW(lp, L"FH2_SpotifyMin.log");
    g_log = CreateFileW(lp, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, 0, NULL);

    static const unsigned char read_pro[14] = {0x48, 0x8b, 0xc4, 0x55, 0x57, 0x41, 0x54,
                                               0x41, 0x56, 0x41, 0x57, 0x48, 0x8b, 0xec};
    static const unsigned char lock_pro[19] = {0x48, 0x89, 0x54, 0x24, 0x10, 0x57, 0x48, 0x83, 0xec, 0x30,
                                               0x48, 0xc7, 0x44, 0x24, 0x20, 0xfe, 0xff, 0xff, 0xff};
    static const unsigned char cmd_pro[15] = {0x48, 0x89, 0x5c, 0x24, 0x18, 0x56, 0x48, 0x83,
                                              0xec, 0x30, 0x80, 0x39, 0x00, 0x8b, 0xda};
    static const unsigned char hud_pro[16] = {0x48, 0x89, 0x74, 0x24, 0x10, 0x57, 0x48, 0x83,
                                              0xec, 0x30, 0x49, 0x8b, 0xf1, 0x48, 0x8b, 0xf9};
    static const unsigned char opt_pro[19] = {0x48, 0x89, 0x4c, 0x24, 0x08, 0x57, 0x48, 0x83, 0xec, 0x40,
                                              0x48, 0xc7, 0x44, 0x24, 0x30, 0xfe, 0xff, 0xff, 0xff};
    static const unsigned char snap_pro[17] = {0x48, 0x89, 0x5c, 0x24, 0x08, 0x57, 0x48, 0x83, 0xec,
                                               0x20, 0x48, 0x8b, 0x59, 0x48, 0x48, 0x8b, 0xf9};
    static const unsigned char seek_pro[14] = {0x40, 0x53, 0x55, 0x56, 0x57, 0x41, 0x56,
                                               0x48, 0x81, 0xec, 0x70, 0x01, 0x00, 0x00};
    static const unsigned char play_pro[16] = {0x40, 0x53, 0x55, 0x56, 0x57, 0x41, 0x56, 0x41,
                                               0x57, 0x48, 0x81, 0xec, 0x68, 0x01, 0x00, 0x00};

    /* the two that make the station exist: all other hooks are only installed when these succeed */
    void **slot = (void **)(g_img + RVA_RADIO_VTABLE + 0xc0);
    DWORD prot;
    int ok =
        *slot == (void *)(g_img + RVA_XBOX_AVAILABLE) && same(g_img + RVA_XBOX_STREAM_READ, read_pro, sizeof(read_pro));
    if (!ok) {
        logs("unexpected game build (wrong exe?): nothing patched\r\n");
        return 0;
    }
    if (!jmp_hook(g_img + RVA_XBOX_STREAM_READ, sizeof(read_pro), stream_read_hook) ||
        !VirtualProtect(slot, sizeof(*slot), PAGE_READWRITE, &prot)) {
        logs("could not patch the station gate/stream\r\n");
        return 0;
    }
    *slot = (void *)gate_hook;
    VirtualProtect(slot, sizeof(*slot), prot, &prot);
    logs("station gate + stream read hooked\r\n");

    g_orig_locked = checked_hook("station lock", RVA_STATION_LOCKED, lock_pro, sizeof(lock_pro), locked_hook);
    g_orig_command = checked_hook("xbox command", RVA_XBOX_COMMAND, cmd_pro, sizeof(cmd_pro), command_hook);
    g_orig_hud = checked_hook("hud radio event", RVA_HUD_RADIO_EVENT, hud_pro, sizeof(hud_pro), hud_hook);
    g_orig_opt = checked_hook("options line", RVA_XBOX_OPTION, opt_pro, sizeof(opt_pro), option_hook);
    g_orig_snap = checked_hook("snapshot copy", RVA_SNAPSHOT_COPY, snap_pro, sizeof(snap_pro), snapshot_hook);
    g_orig_setpos = checked_hook("channel seek", RVA_SET_POSITION, seek_pro, sizeof(seek_pro), set_position_hook);
    g_orig_play = checked_hook("playSound", RVA_PLAY_SOUND, play_pro, sizeof(play_pro), play_sound_hook);
    install_logo(host);

    /* FH2_SpotifyMin.ini, [radio] source=radio (default) | librespot | folder | both */
    wchar_t ini[MAX_PATH * 2], source[32];
    lstrcpyW(ini, g_dir);
    lstrcatW(ini, L"FH2_SpotifyMin.ini");
    if (GetFileAttributesW(ini) == INVALID_FILE_ATTRIBUTES) {
        WritePrivateProfileStringW(L"radio", L"source", L"radio", ini);
        WritePrivateProfileStringW(L"radio", L"folder", L"", ini);
        WritePrivateProfileStringW(L"radio", L"countries", L"IT,GB,US,DE,FR,ES,custom", ini);
        WritePrivateProfileStringW(L"radio", L"language", L"", ini);
    }
    GetPrivateProfileStringW(L"radio", L"source", L"radio", source, 32, ini);
    GetPrivateProfileStringW(L"radio", L"folder", L"", g_folder, MAX_PATH, ini);
    if (!g_folder[0]) {
        lstrcpyW(g_folder, g_dir);
        lstrcatW(g_folder, L"music");
        CreateDirectoryW(g_folder, NULL);
    }
    { /* radio mode settings */
        wchar_t list[160];
        char narrow[160];
        GetPrivateProfileStringW(L"radio", L"countries", L"IT,GB,US,DE,FR,ES,custom", list, 160, ini);
        WideCharToMultiByte(CP_UTF8, 0, list, -1, narrow, sizeof(narrow), NULL, NULL);
        for (char *c = narrow; *c && g_ncountries < 16;) {
            int l = 0;
            while (*c == ' ' || *c == ',')
                ++c;
            while (c[l] && c[l] != ',' && c[l] != ' ' && l < 15) {
                g_countries[g_ncountries][l] = (c[l] >= 'a' && c[l] <= 'z') ? (char)(c[l] - 32) : c[l];
                ++l;
            }
            g_countries[g_ncountries][l] = 0;
            c += l;
            if (l) {
                if (lstrcmpiA(g_countries[g_ncountries], "custom") == 0)
                    lstrcpyA(g_countries[g_ncountries], "custom");
                ++g_ncountries;
            }
        }
        if (!g_ncountries) {
            lstrcpyA(g_countries[0], "IT");
            g_ncountries = 1;
        }
        {
            wchar_t lang[48];
            GetPrivateProfileStringW(L"radio", L"language", L"", lang, 48, ini);
            WideCharToMultiByte(CP_UTF8, 0, lang, -1, g_language, sizeof(g_language), NULL, NULL);
        }
        g_limit = (int)GetPrivateProfileIntW(L"radio", L"limit", 40, ini);
        if (g_limit < 5)
            g_limit = 5;
        if (g_limit > 150)
            g_limit = 150;
        g_cache_hours = (int)GetPrivateProfileIntW(L"radio", L"cache_hours", 12, ini);
        g_osd_on = (int)GetPrivateProfileIntW(L"radio", L"osd", 1, ini) != 0;
        g_osd_secs = (int)GetPrivateProfileIntW(L"radio", L"osd_seconds", 5, ini);
        if (g_osd_secs < 1)
            g_osd_secs = 1;
        if (g_osd_secs > 30)
            g_osd_secs = 30;
        set_key(0, ini, L"next_key", L"F6");
        set_key(1, ini, L"prev_key", L"F5");
        set_key(2, ini, L"country_key", L"F7");
        set_key(3, ini, L"list_key", L"F8");
    }
    int mode = SRC_RADIO;
    if (lstrcmpiW(source, L"librespot") == 0)
        mode = SRC_LIBRESPOT;
    else if (lstrcmpiW(source, L"folder") == 0)
        mode = SRC_FOLDER;
    else if (lstrcmpiW(source, L"both") == 0)
        mode = SRC_BOTH;
    else if (lstrcmpiW(source, L"radio") != 0)
        logs("unknown source in the ini, using radio\r\n");
    g_both = mode == SRC_BOTH;
    g_mode = mode;
    logs(mode == SRC_LIBRESPOT ? "source: librespot (Spotify Premium)\r\n"
         : mode == SRC_FOLDER  ? "source: music folder (mp3/flac/wav)\r\n"
         : mode == SRC_BOTH    ? "source: Spotify (librespot) + internet radio on one dial\r\n"
                               : "source: internet radio\r\n");
    HANDLE t = CreateThread(NULL, 0,
                            (mode == SRC_LIBRESPOT || mode == SRC_BOTH) ? launcher
                            : mode == SRC_FOLDER                        ? folder_thread
                                                                        : radio_thread,
                            NULL, 0, NULL);
    if (mode == SRC_BOTH) {
        HANDLE t2 = CreateThread(NULL, 0, radio_thread, NULL, 0, NULL);
        if (t2)
            CloseHandle(t2);
    }
    if ((mode == SRC_RADIO || mode == SRC_BOTH) && g_osd_on) {
        HANDLE t3 = CreateThread(NULL, 0, osd_thread, NULL, 0, NULL);
        if (t3)
            CloseHandle(t3);
    }
    if (t)
        CloseHandle(t);
    return 1;
}

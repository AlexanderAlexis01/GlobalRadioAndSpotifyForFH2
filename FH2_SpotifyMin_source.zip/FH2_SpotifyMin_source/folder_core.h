/* Local-music decoding for FH2 Spotify Radio (source=folder): mp3 / flac / wav -> 44.1 kHz stereo S16.
   Decoders: dr_mp3, dr_flac, dr_wav (David Reid, public domain / MIT-0). */
#ifndef FOLDER_CORE_H
#define FOLDER_CORE_H
#include <stddef.h>

typedef struct {
    short l, r;
} Frame; /* one stereo sample pair */

#ifdef _WIN32
#include <wchar.h>
typedef wchar_t PathChar;
#else
typedef char PathChar;
#endif

#define FT_MAX_OUT 8192 /* the output buffer passed to ft_read must hold at least this many frames */

typedef struct FolderTrack FolderTrack;
FolderTrack *ft_open(const PathChar *path); /* NULL: unsupported/unreadable file */
size_t ft_read(FolderTrack *t, Frame *out); /* up to FT_MAX_OUT frames at 44100 Hz; 0 = end of track */
void ft_close(FolderTrack *t);
/* live mp3 stream (internet radio): `rd` returns bytes read now (may be short), 0 = end/abort; no seeking needed */
typedef size_t (*FtReadFn)(void *user, void *buf, size_t n);
FolderTrack *ft_open_mp3_stream(FtReadFn rd, void *user);
unsigned ft_source_rate(const FolderTrack *t);
#endif

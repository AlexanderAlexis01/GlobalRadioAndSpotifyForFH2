"""Global Radio HUD logo for FH2: 196x96 RGBA, transparent, same layout as hud_logo/make_logo.py.
Icon: Bootstrap Icons 'globe-americas' + the outer rings of 'broadcast' (MIT).
Font: Montserrat Black Italic (SIL OFL). Usage: python make_logo_global.py [NAME] [TAG] [outdir]"""
import io, os, re, sys
import cairosvg
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
S = 4
W, H = 196, 96
LIGHT, DARK = (64, 196, 255), (16, 142, 220)       # sky blue, two-tone like the stock "pulse" look
FONT = os.path.join(HERE, "Montserrat-BlackItalic.ttf")
NAME = sys.argv[1] if len(sys.argv) > 1 else "global"
TAG = sys.argv[2] if len(sys.argv) > 2 else "RADIO"


def path_d(name):
    return re.search(r' d="([^"]+)"', open(os.path.join(HERE, name + ".svg")).read()).group(1)


def render(d, size, transform=""):
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="{size}" height="{size}">'
           f'<g transform="{transform}"><path fill="rgb{LIGHT}" d="{d}"/></g></svg>')
    return Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode()))).convert("RGBA")


def globe_icon(size):
    rings = render(path_d("broadcast"), size)
    ImageDraw.Draw(rings).ellipse([size * (8 - 5.7) / 16, size * (8 - 5.7) / 16,
                                   size * (8 + 5.7) / 16, size * (8 + 5.7) / 16], fill=(0, 0, 0, 0))  # keep outer rings only
    globe = render(path_d("globe-americas"), size, "translate(8 8) scale(0.64) translate(-8 -8)")
    rings.alpha_composite(globe)
    # darker lower half, same trick as the wordmark
    dark = Image.new("RGBA", rings.size, DARK + (255,))
    mask = rings.getchannel("A").copy()
    ImageDraw.Draw(mask).rectangle([0, 0, size, size // 2], fill=0)
    rings.paste(dark, (0, 0), mask)
    return rings


def two_tone_text(text, font, light, dark):
    box = font.getbbox(text)
    tw, th = box[2] - box[0] + 8 * S, box[3] - box[1] + 8 * S
    mask = Image.new("L", (tw, th), 0)
    ImageDraw.Draw(mask).text((4 * S - box[0], 4 * S - box[1]), text, font=font, fill=255)
    fill = Image.new("RGBA", (tw, th), light + (255,))
    fill.paste(Image.new("RGBA", (tw, th // 2 + 1), dark + (255,)), (0, th // 2))
    out = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    out.paste(fill, (0, 0), mask)
    return out


def logo():
    canvas = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0))
    canvas.alpha_composite(globe_icon(58 * S), (4 * S, 20 * S))
    word = two_tone_text(NAME, ImageFont.truetype(FONT, 50 * S), LIGHT, DARK)
    scale = min(1.0, (W - 68) * S / word.width)
    word = word.resize((int(word.width * scale), int(word.height * scale)), Image.LANCZOS)
    wx, wy = 64 * S, 18 * S
    canvas.alpha_composite(word, (wx, wy))
    tag_font = ImageFont.truetype(FONT, 14 * S)
    d = ImageDraw.Draw(canvas)
    gap = 6 * S
    total = sum(int(tag_font.getlength(c)) for c in TAG) + gap * (len(TAG) - 1)
    x = wx + word.width - 4 * S - total
    for c in TAG:
        d.text((x, wy + word.height - 2 * S), c, font=tag_font, fill=(240, 240, 240, 255))
        x += int(tag_font.getlength(c)) + gap
    shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    shadow.putalpha(canvas.getchannel("A").filter(ImageFilter.GaussianBlur(2 * S)).point(lambda v: int(v * 0.45)))
    final = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    final.alpha_composite(shadow, (0, S))
    final.alpha_composite(canvas)
    return final


if __name__ == "__main__":
    out = sys.argv[3] if len(sys.argv) > 3 else HERE
    master = logo()
    master.save(os.path.join(out, "global_logo_master_784x384.png"))
    im = master.resize((W, H), Image.LANCZOS)
    im.save(os.path.join(out, "global_logo.png"))
    prev = Image.new("RGBA", (W, H), (120, 120, 120, 255)); prev.alpha_composite(im)
    prev.resize((W * 3, H * 3), Image.NEAREST).convert("RGB").save(os.path.join(out, "global_preview.png"))

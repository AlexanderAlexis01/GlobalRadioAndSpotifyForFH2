/* Small portable helpers for the internet-radio client: URL splitting, HTTP / SHOUTcast ("ICY 200 OK")
   response-head parsing, redirect resolving, content-type check. No WinAPI, no CRT. */
#ifndef NET_UTIL_H
#define NET_UTIL_H

static int nu_lower(int c) {
    return (c >= 'A' && c <= 'Z') ? c + 32 : c;
}
static int nu_starts_ci(const char *s, const char *p) {
    while (*p) {
        if (nu_lower((unsigned char)*s) != nu_lower((unsigned char)*p))
            return 0;
        ++s;
        ++p;
    }
    return 1;
}
static int nu_has_ci(const char *s, const char *needle) {
    for (; *s; ++s)
        if (nu_starts_ci(s, needle))
            return 1;
    return 0;
}
static void nu_cat(char *out, int cap, int *pos, const char *s) {
    while (*s && *pos + 1 < cap)
        out[(*pos)++] = *s++;
    out[*pos] = 0;
}

/* "http://host:port/path?x" -> parts (path always starts with '/'). 1 = ok */
static int nu_split_url(const char *url, int *https, char *host, int hcap, int *port, char *path, int pcap) {
    int i = 0, h = 0, pl = 0;
    if (nu_starts_ci(url, "http://")) {
        *https = 0;
        i = 7;
        *port = 80;
    } else if (nu_starts_ci(url, "https://")) {
        *https = 1;
        i = 8;
        *port = 443;
    } else
        return 0;
    if (url[i] == '[') { /* IPv6 literal */
        ++i;
        while (url[i] && url[i] != ']') {
            if (h + 1 < hcap)
                host[h++] = url[i];
            ++i;
        }
        if (url[i] == ']')
            ++i;
    } else {
        while (url[i] && url[i] != ':' && url[i] != '/' && url[i] != '?' && url[i] != '#') {
            if (h + 1 < hcap)
                host[h++] = url[i];
            ++i;
        }
    }
    host[h] = 0;
    if (!h)
        return 0;
    if (url[i] == ':') {
        int p = 0, d = 0;
        ++i;
        while (url[i] >= '0' && url[i] <= '9') {
            p = p * 10 + (url[i] - '0');
            if (p > 65535)
                return 0;
            ++i;
            ++d;
        }
        if (!d || !p)
            return 0;
        *port = p;
    }
    if (url[i] == '?')
        path[pl++] = '/';
    else if (url[i] != '/') {
        path[0] = '/';
        path[1] = 0;
        return 1;
    }
    while (url[i] && url[i] != '#') {
        if (pl + 1 < pcap)
            path[pl++] = url[i];
        else
            return 0;
        ++i;
    }
    path[pl] = 0;
    return 1;
}

/* length of the response head including the blank line, 0 = not complete yet */
static int nu_head_end(const char *b, int n) {
    for (int i = 0; i + 3 < n; ++i)
        if (b[i] == '\r' && b[i + 1] == '\n' && b[i + 2] == '\r' && b[i + 3] == '\n')
            return i + 4;
    for (int i = 0; i + 1 < n; ++i)
        if (b[i] == '\n' && b[i + 1] == '\n')
            return i + 2;
    return 0;
}

/* status line "HTTP/1.x NNN ..." or SHOUTcast "ICY NNN OK"; content-type (lower-cased) and location.
   returns the status code, 0 when the first line is neither */
static int nu_parse_head(const char *h, int n, char *ctype, int ccap, char *loc, int lcap) {
    int status = 0, i = 0;
    if (ccap)
        ctype[0] = 0;
    if (lcap)
        loc[0] = 0;
    if (!(nu_starts_ci(h, "HTTP/") || nu_starts_ci(h, "ICY ")))
        return 0;
    while (i < n && h[i] != ' ' && h[i] != '\n')
        ++i;
    while (i < n && h[i] == ' ')
        ++i;
    while (i < n && h[i] >= '0' && h[i] <= '9') {
        status = status * 10 + (h[i] - '0');
        ++i;
    }
    while (i < n && h[i] != '\n')
        ++i; /* end of the status line */
    while (i < n) {
        int ls, le, colon;
        ++i; /* start of next line */
        ls = i;
        while (i < n && h[i] != '\n')
            ++i;
        le = i;
        while (le > ls && h[le - 1] == '\r')
            --le;
        if (le == ls)
            break; /* blank line */
        colon = ls;
        while (colon < le && h[colon] != ':')
            ++colon;
        if (colon >= le)
            continue;
        {
            int is_ct = (colon - ls == 12) && nu_starts_ci(h + ls, "content-type");
            int is_loc = (colon - ls == 8) && nu_starts_ci(h + ls, "location");
            int v = colon + 1, w = 0;
            while (v < le && (h[v] == ' ' || h[v] == '\t'))
                ++v;
            if (is_ct && ccap) {
                while (v < le && w + 1 < ccap)
                    ctype[w++] = (char)nu_lower((unsigned char)h[v++]);
                ctype[w] = 0;
            } else if (is_loc && lcap) {
                while (v < le && w + 1 < lcap)
                    loc[w++] = h[v++];
                loc[w] = 0;
            }
        }
    }
    return status;
}

/* Location header -> absolute URL (absolute, or "/path" relative to the current host). 1 = ok */
static int nu_resolve(int https, const char *host, int port, const char *loc, char *out, int cap) {
    int pos = 0;
    out[0] = 0;
    if (nu_starts_ci(loc, "http://") || nu_starts_ci(loc, "https://")) {
        nu_cat(out, cap, &pos, loc);
        return 1;
    }
    if (loc[0] == '/') {
        char num[8];
        int d = 0, v = port;
        char rev[8];
        nu_cat(out, cap, &pos, https ? "https://" : "http://");
        nu_cat(out, cap, &pos, host);
        if (port != (https ? 443 : 80)) {
            do {
                rev[d++] = (char)('0' + v % 10);
                v /= 10;
            } while (v);
            for (int k = 0; k < d; ++k)
                num[k] = rev[d - 1 - k];
            num[d] = 0;
            nu_cat(out, cap, &pos, ":");
            nu_cat(out, cap, &pos, num);
        }
        nu_cat(out, cap, &pos, loc);
        return 1;
    }
    return 0;
}

/* is this Content-Type (already lower-case) a raw MP3 stream? playlists / web pages are not */
static int nu_ctype_ok(const char *lc) {
    if (!lc[0])
        return 1;
    if (nu_has_ci(lc, "mpegurl") || nu_has_ci(lc, "scpls") || nu_has_ci(lc, "html") || nu_has_ci(lc, "text/") ||
        nu_has_ci(lc, "xml") || nu_has_ci(lc, "json"))
        return 0;
    return nu_has_ci(lc, "mpeg") || nu_has_ci(lc, "mp3") || nu_has_ci(lc, "octet");
}
#endif
